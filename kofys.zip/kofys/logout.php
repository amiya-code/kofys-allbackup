<?php
	include "includes/common.php";
	$objMysql = new MysqlFns(); 
	
	$sid=$_SESSION["sid"];
	$userid=$_SESSION["userid"];
	
	$delete=mysql_query("DELETE FROM `phpbb_sessions` WHERE  `session_id` = '".$sid."'");
	
	$delete1=mysql_query("DELETE FROM session  WHERE  userid = '".$userid."'");
	
	$delete2=mysql_query("DELETE FROM `cometchat_status` WHERE  `userid` ='".$userid."'");
 
 session_destroy();
	//unset($_SESSION);
	
	setcookie("sellcars", "", time()-3600);
	setcookie("sellrvs", "", time()-3600);
	setcookie("sellboat", "", time()-3600);
	setcookie("sellmotor", "", time()-3600);
	setcookie("blog", "", time()-3600);

 header("location:index.php");
	
?>
