<?php   
	
	include "includes/common.php";
	include_once $config['SiteClassPath']."class.Register.php";
	include $config['SiteClassPath']."class.split_page_results.php";
	include_once $config['SiteClassPath']."class.index.php";
	
	
	$ObjIndex=new Index();
	
	$ObjReg=new Register();
	
	$ObjReg->Get_Recent_mem();
	
	$ObjReg->Get_Country(); 
	
	
	
	if($_POST['login']!='') 
	{
	$page="home";
	$ObjReg->Check_MemberLog($_REQUEST,$page);
	} 
	
	
	
	if($_REQUEST['Find_rv_x'])
	{
	
	 $ObjIndex->Find_auto();
	 
	 }
	
	if($_REQUEST['product_id'] != ''){
	
	$ObjIndex->product_details();
	
	}
	
	
	$ObjIndex->view_product_images();
	
	$ObjIndex->Year();
	$ObjIndex->select_Category();
	
	
	
	$objSmarty->assign("ObjReg",$ObjReg); 
	$objSmarty->assign("ObjIndex",$ObjIndex); 
	$objSmarty->assign("IncludeTpl", "rv_details.tpl");	 
	$objSmarty->display("pagetemplate.tpl"); 
	
?>