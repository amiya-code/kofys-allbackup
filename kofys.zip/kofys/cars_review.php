<?php   
	
	include "includes/common.php";
	include_once $config['SiteClassPath']."class.Register.php";
	include $config['SiteClassPath']."class.split_page_results.php";
	include_once $config['SiteClassPath']."class.sell.php";
	
	$objSell=new sell();
	$ObjReg=new Register();

	$cid=$_REQUEST['cid'];
	$message=$_REQUEST['msg'];
	
	$email=$_SESSION['usermail'];
	
	$username=$_SESSION['fname'];

	$payment_status = $ObjReg->Get_individualpayment($_SESSION['userid']);
	/*if(!empty($payment_status)){
		$status = 0;
	}else{
		$status = 1;
	}*/
	if($_SESSION['user_type']=='individual'){
		$status = 1;
	}else{
		$status = 1;
	}
	$status = $status*1;
	$objSmarty->assign("paymentStatus",$status); 
	
	//$ObjReg=new Register();
	//$ObjReg->LoginCheck();
	//if($_SESSION['userid']!=='')
	//{
	//$page="home";
	//$ObjReg->Check_MemberLog($_REQUEST,$page);
//	}
	
	$objSell->select_carmake();
	
	$objSell->select_car_review();
	
	$objSell->select_car_thumb();
	$objSmarty->assign("message",$message);
	$objSmarty->assign("msg",$msg);
	$objSmarty->assign("email",$email);
	$objSmarty->assign("username",$username);
	$objSmarty->assign("cid",$cid);
	$objSmarty->assign("objSell",$objSell); 
	$objSmarty->assign("IncludeTpl", "cars_review.tpl");	 
	$objSmarty->display("pagetemplate.tpl"); 
	
?>