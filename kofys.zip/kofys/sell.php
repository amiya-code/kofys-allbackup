<?php   
	
	include "includes/common.php";
	include_once $config['SiteClassPath']."class.Register.php";
	include $config['SiteClassPath']."class.split_page_results.php";

	$ObjReg=new Register();
	
	$ObjReg->Get_Recent_mem();
	
	$ObjReg->Get_Country();
	
	$ObjReg->Get_Country();
	$payment_status = $ObjReg->Get_businesspayment($_SESSION['userid']); 
	if(!empty($payment_status)){
		$status = 0;
	}else{
		$status = 1;
	}
	$status = $status*1;

	 if($_SESSION['user_type']=='individual'){
	$individual_paymentStatus = $payment_status = $ObjReg->Get_individualpendingpayment($_SESSION['userid']);
			if(!empty($individual_paymentStatus)){
				$pendingstatus = 0;
			}else{
				$pendingstatus = 1;
			}
	}else{
		 $pendingstatus = 1;
	 }
	$pendingstatus = $pendingstatus*1;
	
	$objSmarty->assign("individualpendingstatus",$pendingstatus); 
	$objSmarty->assign("paymentStatus",$status); 
	$objSmarty->assign("ObjReg",$ObjReg); 
	$objSmarty->assign("IncludeTpl", "sell.tpl");	 
	$objSmarty->display("pagetemplate.tpl"); 
	
?>