<?php   
	include "includes/common.php";
	include_once $config['SiteClassPath']."class.Register.php";
	
	$ObjReg=new Register();

	$Id = $_REQUEST['id'];
	$a = $ObjReg->price_info($Id);
	print_r($a[0]['id'].'-'.$a[0]['price'].'-'.$a[0]['lowerlimit'].'-'.$a[0]['upperlimit']);
	
?>