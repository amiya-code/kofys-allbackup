<?php   
	
	include "includes/common.php";
	include_once $config['SiteClassPath']."class.Register.php";
	include $config['SiteClassPath']."class.split_page_results.php";
	include_once $config['SiteClassPath']."class.myads.php";
	
	
	$Objmyads=new myads();
	
	$ObjReg=new Register();
	
	$ObjReg->LoginCheck();  

	if($_REQUEST['uid']!='')
	{
	
	//$DelQuery = "update tbl_member set status =1 Where id IN ( ".$BanIds." )" ;
	//$updat = "update tbl_category set status = 0 where category_id = '".$_REQUEST['uid']."'";
	$DelQry="Delete from tbl_category where category_id='".$_REQUEST['uid']."'";
	$Objmyads->ExecuteQuery($DelQry,"update");
	}
	
	if($_REQUEST['mid']!='')
	{
	
	//$DelQuery = "update tbl_member set status =1 Where id IN ( ".$BanIds." )" ;
	$updat = "update tbl_category set status = 1 where category_id = '".$_REQUEST['mid']."'";
	//$DelQry="Delete from tbl_category where category_id='".$_REQUEST['uid']."'";
	$Objmyads->ExecuteQuery($updat,"update");
	}
	
	
	
	
	if($_SESSION['userid']!=='')
	{
	$Objmyads->select_trash();	
	}
	
	


	 
	$objSmarty->assign("ObjReg",$ObjReg); 
	$objSmarty->assign("IncludeTpl", "trash.tpl");
	$objSmarty->display("pagetemplate.tpl"); 
	
?>