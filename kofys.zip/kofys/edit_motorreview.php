<?php   
	
	include "includes/common.php";
	include_once $config['SiteClassPath']."class.Register.php";
	include $config['SiteClassPath']."class.split_page_results.php";
	include_once $config['SiteClassPath']."class.sell.php";
	$objSell=new sell();
	$objReg=new Register();
	
	$objReg->LoginCheck();
	
	$var=$_SERVER['REQUEST_URI'];

 	$tt=explode('/',$var);

	$expire=time()+60*60*24*30;
	setcookie("sellcars", $var, $expire);
	
	$objSell->Year();
	
	$objSell->select_edit_motor();
	
	$objSell->select_motormake();
	
	
	if($_REQUEST['Update'])
	{
	$objSell->edit_sellmotor();
	}
	
	
	
	
	
	$objSmarty->assign("ObjReg",$ObjReg); 
	$objSmarty->assign("IncludeTpl", "edit_motorreview.tpl");	 
	$objSmarty->display("pagetemplate.tpl"); 
	
?>