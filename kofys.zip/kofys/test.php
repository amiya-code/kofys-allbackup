<script type="text/javascript">
google_ad_client = "ca-pub-7537123598015029";
google_ad_slot = "8250534723";
google_ad_width = 728;
google_ad_height = 90;
</script>
<script type="text/javascript"
src="https://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>