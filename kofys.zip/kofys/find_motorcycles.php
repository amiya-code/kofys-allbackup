<?php  	
 
/*	Debug control for smarty template please comment these lines before uploading*/
//########################################################################
//########################################################################

$smarty->debugging = TRUE;
//########################################################################
//########################################################################

	include "includes/common.php";
	

	include_once $config['SiteClassPath']."class.Register.php";
	include_once $config['SiteClassPath']."class.sitemap.php";
	include $config['SiteClassPath']."class.split_page_results.php";
	include_once $config['SiteClassPath']."class.index.php";
	include_once $config['SiteClassPath']."class.review.php";
	include_once $config['SiteClassPath']."class.Content.php";
	include_once $config['SiteClassPath']."class.car_year.php";
	
    //header('Content-Type: image/jpg');
	$objcon=new Content();
	
	$objcaryear=new caryear();

	$objcon->select_resources();
	
	$objcon->select_articles();
	
	$objcon->select_priceguide();
	
	
//#######################################	

// code to fetch home page text content and meta detail  ! start !	
	
	$objsitemap = new sitemap;
	
	$objsitemap->MOTORCYCLES();
	

//  ! END !

//
//Assign Body_style
//
	$sql = "SELECT DISTINCT body_style FROM tbl_category ORDER BY body_style DESC";
	$result = mysql_query($sql) or die('Query failed.');
	while($row = mysql_fetch_array($result))
	{
	$body_style[]=ucwords($row['body_style']);
	}
	$objSmarty->assign('items',$body_style);
	
//########################################	
	
	$imgsql = "select image_name from tbl_banners where 1=1";
		$result = mysql_query($imgsql);
		$img=0;
		while($value = mysql_fetch_array($result)){
			++$img;
				if($img==1){
					$image1 = $value['image_name'];
				}else if($img==2){
					$image2 = $value['image_name'];
				}else if($img==3){
					$image3 = $value['image_name'];
				}else if($img==4){
					$image4 = $value['image_name'];
				}else if($img==5){
					$image5 = $value['image_name'];
				}
		}
		
		$objSmarty->assign("image1",$image1);	
		$objSmarty->assign("image2",$image2);	
		$objSmarty->assign("image3",$image3);	
		$objSmarty->assign("image4",$image4);	
		$objSmarty->assign("image5",$image5);	

	$objreview = new review();
	
	$ObjIndex=new Index();
	
	$ObjReg=new Register();
	
	$ObjReg->Get_Recent_mem();
	
	$ObjReg->Get_Country();
	
	$objreview->select_cars_Make();
	
	$objreview->Year(); 
	
	
	if($_POST['login']!='') 
	{
	
	$page="home"; 
	
	$ObjReg->Check_MemberLog($_REQUEST,$page);
	
	} 
	
	//pr($_REQUEST);
	if(($_REQUEST['make'] && $_REQUEST['year'])!==''){
		$objreview->select_cars_review();
	}	
		//if($_POST['submit']=='Add')
		  //{
		//$objreview->add_cars_review();
		   //$objstore->Add_store($_REQUEST);  
		  //}
	
	
	/*if(($_REQUEST['make']&&$_REQUEST['year'])!=='')
	{
	$objreview->select_cars_year();
	}	*/
	
	if($_REQUEST['Find_auto_x'])
	{
	
	 $ObjIndex->Find_auto();	
	// print_r($ankur);
	 }
	 
	 
	 if($_REQUEST['Find_motor_x'])
	{
	
	 $ObjIndex->Find_motor();
	 
	 }
	 
	 
	  if($_REQUEST['Find_boat_x'])
	{
	
	 $ObjIndex->Find_boat();
	 
	 }
	 
	  if($_REQUEST['Find_rv_x'])
	{
	
	 //$ObjIndex->Find_rv();
	 
	 }
	
	
	if($_REQUEST['review_x'] != '')
	{
	   
	 $objreview->review_details();
	
	}
	
	if($_REQUEST['activation']=='Active')
	{	
		
		$SelQu = "select  * from tbl_member where id='".$_REQUEST['maxid']."'";
		$SelF=$ObjReg->ExecuteQuery($SelQu, "select");
		$total=count($SelF);
		if($total!=0)
		{
	    $SelQuery = "select  * from tbl_member where id='".$_REQUEST['maxid']."' and status = 1";
		$SelFrid=$ObjReg->ExecuteQuery($SelQuery, "select");
		
	     $Total=count($SelFrid);
		 
		 if($Total==0) {
	
	 			$query = "update tbl_member set status=1 where id ='".$_REQUEST['maxid']."'";
	 			$result =$ObjReg->ExecuteQuery($query,"update");
	 
			
				
				 
		  }
		  else
		  {
		    $objSmarty->assign("msg","Already Activated");
		  }
		   }
		  else
		  {
		    $objSmarty->assign("msg","User not Exist");
		  }
	}
	
	

	

	
	$ObjIndex->Year();
	
	$ObjIndex->select_Category();
	
	//$ObjIndex->select_Boat();
	
	$ObjIndex->select_Motor();
	
	//$ObjIndex->select_Rvs();
	
	
	//$ObjIndex->boattype();
	//$ObjIndex->motorcycletype();
	$ObjIndex->motorcyclecategory();
	
	//$ObjIndex->rvstype();
	
	$objcaryear->select_caryear();
	
	$objSmarty->assign("ObjReg",$ObjReg); 
	$objSmarty->assign("IncludeTpl", "find_motorcycles.tpl");	 
	$objSmarty->display("pagetemplate.tpl"); 
	
?>