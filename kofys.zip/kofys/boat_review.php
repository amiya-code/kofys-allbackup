<?php   
	
	include "includes/common.php";
	include_once $config['SiteClassPath']."class.Register.php";
	include $config['SiteClassPath']."class.split_page_results.php";
	include_once $config['SiteClassPath']."class.sell.php";
	$objSell=new sell();
	$cid=$_REQUEST['cid'];
	
	$email=$_SESSION['usermail'];
	
	$username=$_SESSION['fname'];
	
	$objSell->select_boatmake();
	
	$objSell->select_boat_review();
	
	$objSell->select_boat_thumb();
	if($_SESSION['user_type']=='individual'){
		$status = 1;
	}else{
		$status = 1;
	}
	$status = $status*1;
	$objSmarty->assign("paymentStatus",$status); 
	
	$objSell->boattype();
	
	$objSmarty->assign("email",$email);
	$objSmarty->assign("username",$username);
	$objSmarty->assign("cid",$cid);
	$objSmarty->assign("objSell",$objSell); 
	$objSmarty->assign("IncludeTpl", "boat_review.tpl");	 
	$objSmarty->display("pagetemplate.tpl"); 
	
?>