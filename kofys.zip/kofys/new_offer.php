<?php 
	include "includes/common.php";
	include_once $config['SiteClassPath']."class.Register.php";
	include_once $config['SiteClassPath']."class.index.php";
	include $config['SiteClassPath']."class.split_page_results.php";
	$ObjIndex=new Index();
	$mem_id=$_SESSION["userid"];
	
	$ObjReg=new Register();

	$ObjReg->LoginCheck();  

	$ObjReg->Login_UserDetails();
	if($_SESSION['user_type']=='business'){

	$ObjReg->business_expiredatematch($_SESSION['userid']); 
	}
	
	
	$ObjReg->select_offer();  
	$payment_status = $ObjReg->user_subscription_payment($_SESSION['userid']); 
	$payment_status = $payment_status*1;

	if($_REQUEST['action']=='delete'){
	
     $offer_id=$_REQUEST['offer_id'];
	 $ObjReg->deleteoffer($offer_id); 
	 header('location:offer.php');
	}
	$page=$_GET["page"];
	if(empty($page)){
		$page =1;
	}
	$lsort='asc';
	if($_GET["sort"]=="asc" && $_GET["column"]=="name" ){//sort by title
  		$column1='first_name';
  		$qsort='asc';
  		$lsort='desc';
		//echo 'hi'; 
	}
	if($_GET["sort"]=="desc" && $_GET["column"]=="name" ){//sort by title
  		$column1='first_name';
  		$qsort='desc';
  		$lsort='asc';
		//echo 'bye';
	}if($_GET["sort"]=="asc" && $_GET["column"]=="year" ){//sort by title
  		$column1='year';
  		$qsort='asc';
  		$lsort='desc';
		//echo 'hi'; 
	}
	if($_GET["sort"]=="desc" && $_GET["column"]=="year" ){//sort by title
  		$column1='year';
  		$qsort='desc';
  		$lsort='asc';
		//echo 'bye';
	}
	if($_GET["sort"]=="asc" && $_GET["column"]=="make" ){//sort by title
  		$column1='model_name';
  		$qsort='asc';
  		$lsort='desc';
		//echo 'hi'; 
	}
	if($_GET["sort"]=="desc" && $_GET["column"]=="make" ){//sort by title
  		$column1='model_name';
  		$qsort='desc';
  		$lsort='asc';
		//echo 'bye';
	}
	if($_GET["sort"]=="asc" && $_GET["column"]=="phone" ){//sort by title
  		$column1='phone';
  		$qsort='asc';
  		$lsort='desc';
		//echo 'hi'; 
	}
	if($_GET["sort"]=="desc" && $_GET["column"]=="phone" ){//sort by title
  		$column1='phone';
  		$qsort='desc';
  		$lsort='asc';
		//echo 'bye';
	}
	if($_GET["sort"]=="asc" && $_GET["column"]=="price" ){//sort by title
  		$column1='price_offer';
  		$qsort='asc';
  		$lsort='desc';
		//echo 'hi'; 
	}
	if($_GET["sort"]=="desc" && $_GET["column"]=="price" ){//sort by title
  		$column1='price_offer';
  		$qsort='desc';
  		$lsort='asc';
		//echo 'bye';
	}
	if($_GET["sort"]=="asc" && $_GET["column"]=="dated" ){//sort by title
  		$column1='dated';
  		$qsort='asc';
  		$lsort='desc';
		//echo 'hi'; 
	}
	if($_GET["sort"]=="desc" && $_GET["column"]=="dated" ){//sort by title
  		$column1='dated';
  		$qsort='desc';
  		$lsort='asc';
		//echo 'bye';
	}
	if(isset($_POST)){
		
		if($_POST['search']!=''){
			$searchname=$_POST['searchname'];
			$searchby= $_REQUEST['serchby'];
		}
	}
	$ObjReg->filterSearch($searchname,$searchby,$column1,$qsort,$lsort);
	
	

  //$Objsearch->Profile_View($mem_id); 
 $objSmarty->assign("searchname",$searchname);
   $objSmarty->assign("searchby",$searchby);
$objSmarty->assign("page",$page);
$objSmarty->assign("lsort",$lsort);
$objSmarty->assign("ObjReg",$ObjReg);
$objSmarty->assign("payment_status", $payment_status);
$objSmarty->assign("IncludeTpl", "new_offer.tpl");

$objSmarty->display("pagetemplate.tpl");

?>