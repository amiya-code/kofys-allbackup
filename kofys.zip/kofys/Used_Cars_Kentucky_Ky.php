<?php   
	
	include "includes/common.php";
	include_once $config['SiteClassPath']."class.sitemap.php";
	include $config['SiteClassPath']."class.split_page_results.php";
	$objsitemap = new sitemap;
	
	$objsitemap->Used_Cars_Kentucky_Ky();
	
	$objSmarty->assign("ObjReg",$ObjReg); 
	$objSmarty->assign("IncludeTpl", "Used_Cars_Kentucky_Ky.tpl");	 
	$objSmarty->display("pagetemplate.tpl"); 
	
?>