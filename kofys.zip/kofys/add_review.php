<?php   
	
	include "includes/common.php";
	include_once $config['SiteClassPath']."class.Register.php";
	include $config['SiteClassPath']."class.split_page_results.php";
	include_once $config['SiteClassPath']."class.index.php";
	
		include_once $config['SiteClassPath']."class.review.php";
	
	$objreview = new review();
	$objcontact = new Register;
	$ObjIndex=new Index();
	
	if($_REQUEST['submit'])
	{
	echo 
	$objreview->add_rev();
	}
	
	
	
	$objSmarty->assign("objcontact",$ObjReg); 
	$objSmarty->assign("IncludeTpl", "add_review.tpl");	 
	$objSmarty->display("pagetemplate.tpl"); 
	
?>