<?php 
	include "includes/common.php";
	include_once $config['SiteClassPath']."class.Register.php";
	
	$ObjReg=new Register();

	
	if($_POST['login']!='')
	{
		$ObjReg->Check_MemberLog($_REQUEST);
	}
	
	
	if($_REQUEST['renew']!='')
	{
		$ObjReg->renew_payment_subscription($_SESSION['userid']);
	}
	$ObjReg->Get_Country();
	$ObjReg->Get_Subscription();

if($_REQUEST['renew']!=''){
	$objSmarty->assign("amount",$_POST['subs_price']);
	$ObjReg->Profile_user($_SESSION); 
	$objSmarty->assign("IncludeTpl", "due_payment.tpl");
}else{
	$objSmarty->assign("IncludeTpl", "renew.tpl");
}

$objSmarty->display("pagetemplate.tpl");
?>