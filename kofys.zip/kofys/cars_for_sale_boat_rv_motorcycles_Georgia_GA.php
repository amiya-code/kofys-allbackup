<?php   
	
	include "includes/common.php";
	include_once $config['SiteClassPath']."class.sitemap.php";
	include $config['SiteClassPath']."class.split_page_results.php";
	$objsitemap = new sitemap;
	
    $objsitemap->cars_for_sale_boat_rv_motorcycles_Georgia_GA();
	
	$objSmarty->assign("ObjReg",$ObjReg); 
	$objSmarty->assign("IncludeTpl", "cars_for_sale_boat_rv_motorcycles_Georgia_GA.tpl");	 
	$objSmarty->display("pagetemplate.tpl"); 
	
?>