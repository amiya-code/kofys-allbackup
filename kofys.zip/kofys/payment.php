<?php 
	include "includes/common.php";
	include_once $config['SiteClassPath']."class.Register.php";
	
	$ObjReg=new Register();
	
	
	
	if($_POST['login']!='')
	{
		$ObjReg->Check_MemberLog($_REQUEST);
	}
	
	
	
//this code is used for payment gateway:  START//		

if($_REQUEST['perform'] != '') {

	
//echo "<table border='0' width='40%' cellspacing='2' cellpadding='2' align='center'>";

require_once("paypal_pro.inc.php");
$firstName =urlencode( $_POST['firstName']);
$lastName =urlencode( $_POST['lastName']);
$creditCardType =urlencode( $_POST['creditCardType']);
$creditCardNumber = urlencode($_POST['creditCardNumber']);
$expDateMonth =urlencode( $_POST['expDateMonth']);
$padDateMonth = str_pad($expDateMonth, 2, '0', STR_PAD_LEFT);
$expDateYear =urlencode( $_POST['expDateYear']);
$cvv2Number = urlencode($_POST['cvv2Number']);
$address1 = urlencode($_POST['address1']);
$address2 = urlencode($_POST['address2']);
$city = urlencode($_POST['city']);
$state =urlencode( $_POST['state']);
$zip = urlencode($_POST['zip']);
$amount = urlencode($_POST['amount']);
$currencyCode="USD";
$paymentType=urlencode($_POST['paymentType']);

 $nvpstr='&PAYMENTACTION=Authorization&AMT='.$amount.'&CREDITCARDTYPE='.$creditCardType.'&ACCT='.$creditCardNumber.'&EXPDATE='.         $padDateMonth.$expDateYear.'&CVV2='.$cvv2Number.'&FIRSTNAME='.$firstName.'&LASTNAME='.$lastName.'&STREET='.$address1.'&CITY='.$city.'&STATE='.$state.'&ZIP='.$zip.'&COUNTRYCODE=US&CURRENCYCODE='.$currencyCode; 
 /********sellers account('username','password','signature')**********/
$paypalPro = new paypal_pro('dodziouz_api1.yahoo.com', 'KL8YP3NUV5WK6QFH', 'Agcfg5RFxkUAc8zYWpyZ47MgcVPwAeUC2Qv-RQq.T5gL8958w0xA1XeP', '', '', TRUE, FALSE );
$resArray = $paypalPro->hash_call("doDirectPayment",$nvpstr);
$ack = strtoupper($resArray["ACK"]);
$useremail=$_POST['useremail'];
if($ack!="SUCCESS")
{
	$objSmarty->assign("ACK",$resArray["ACK"]);
	$objSmarty->assign("CORRELATIONID",$resArray['CORRELTIONID']);
	$objSmarty->assign("IncludeTpl", "perform_error.tpl");
}else{
	$objSmarty->assign("TRANSACTIONID",$resArray["TRANSACTIONID"]);
	$objSmarty->assign("AMT",$currencyCode.$resArray['AMT']);
	$objSmarty->assign("msg","Sucess");
    $objSmarty->assign("IncludeTpl", "perform.tpl");
    $user_id=$ObjReg->Get_user_id($useremail);
    $ObjReg->update_paymentinfo($user_id,$resArray["TRANSACTIONID"]);


}

}

/*******************for standard paypal************/
if(isset($_GET['st'])){
	if($_GET['st']!='Completed'){
		$objSmarty->assign("ACK",$_GET['st']);
		$objSmarty->assign("CORRELATIONID",$_GET['tx']);
		$objSmarty->assign("IncludeTpl", "perform_error.tpl");
	}else{
	$objSmarty->assign("TRANSACTIONID",$_GET['tx']);
	$objSmarty->assign("AMT",$_GET['amt']);
	$objSmarty->assign("msg","Success");
    $objSmarty->assign("IncludeTpl", "perform.tpl");
	if(empty($_SESSION['userid'])){
    $user_id=$ObjReg->Get_lastuser_id($useremail);
	$ObjReg->update_paymentinfo($user_id,$_GET['tx']);
	}else{
	if($_SESSION['user_type']=='individual'){
	$user_id=$_SESSION['userid'];
	$category_id = $ObjReg->Individual_lastcategory($_SESSION);
    $ObjReg->insert_individualpaymentinfo($user_id,$category_id,$_GET['tx']);
	}else{
	$user_id=$_SESSION['userid'];
	$ObjReg->update_paymentinfo($user_id,$_GET['tx']);
	}
	}
	}
}
/*******************end for standard paypal************/

//this code is used for payment gateway:  END//		

	$ObjReg->Get_Country();
	$ObjReg->Get_Subscription();
	
	
	if($_REQUEST['type'] == 'business' && !isset($_GET['st'])) 
	{
		
		//echo 'hii'; 
		//print_r($_POST);
		$fname = $_POST['FirstName'];
		$lname = $_POST['LastName'];
		$city = $_POST['city'];
		$state = $_POST['state'];
		$country = $_POST['Address_Country'];
		$zipcode = $_POST['zipcode'];
		$amount = $_POST['subs_price'];
		$email = $_POST['email'];
	
		if($_REQUEST['regist'] != '') {
		$ObjReg->Newmember_Register(); 
		}
		$objSmarty->assign("fname",$fname);
		$objSmarty->assign("lname",$lname);
		$objSmarty->assign("city",$city);
		$objSmarty->assign("state",$state);
		$objSmarty->assign("country",$country);
		$objSmarty->assign("zipcode",$zipcode);
		$objSmarty->assign("amount",$amount);
		$objSmarty->assign("useremail",$email);
		$objSmarty->assign("ObjReg",$ObjReg);
		if($_REQUEST['perform'] == '') {
		//$objSmarty->assign("IncludeTpl", "business_payment.tpl");
		$objSmarty->assign("IncludeTpl", "business_payment_paypal_standard.tpl");
		}
	   
	}else if($_REQUEST['type'] == 'individual' && !isset($_GET['st']))
	{
		
	    $fname = $_POST['FirstName'];
		$lname = $_POST['LastName'];
		$city = $_POST['city'];
		$state = $_POST['state'];
		$country = $_POST['Address_Country'];
		$zipcode = $_POST['zipcode'];
		$amount = 10;
		$email = $_POST['email'];
		
		if($_REQUEST['regist'] != '') {
		$ObjReg->Newmember_Register(); 
		}
	    
		$objSmarty->assign("fname",$fname);
		$objSmarty->assign("lname",$lname);
		$objSmarty->assign("city",$city);
		$objSmarty->assign("state",$state);
		$objSmarty->assign("country",$country);
		$objSmarty->assign("zipcode",$zipcode);
		$objSmarty->assign("amount",$amount);
		$objSmarty->assign("useremail",$email);
		$objSmarty->assign("ObjReg",$ObjReg);
		if($_REQUEST['perform'] == '') {
		//$objSmarty->assign("IncludeTpl", "business_payment.tpl");
		$objSmarty->assign("IncludeTpl", "business_payment_paypal_standard.tpl");
		}
		
		$objSmarty->assign("ObjReg",$ObjReg);

	}
	

$objSmarty->display("pagetemplate.tpl");
?>