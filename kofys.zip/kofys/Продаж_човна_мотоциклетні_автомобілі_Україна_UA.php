<?php   
	
	include "includes/common.php";
	include_once $config['SiteClassPath']."class.sitemap.php";
	include $config['SiteClassPath']."class.split_page_results.php";
	$objsitemap = new sitemap;
	
    $objsitemap->Продаж_човна_мотоциклетні_автомобілі_Україна_UA();
	
	$objSmarty->assign("ObjReg",$ObjReg); 
	$objSmarty->assign("IncludeTpl", "Продаж_човна_мотоциклетні_автомобілі_Україна_UA.tpl");	 
	$objSmarty->display("pagetemplate.tpl"); 
	
?>