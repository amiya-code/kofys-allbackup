<?php   
	
	include "includes/common.php";
	include_once $config['SiteClassPath']."class.Register.php";
	include $config['SiteClassPath']."class.split_page_results.php";
	include_once $config['SiteClassPath']."class.index.php";
	
	include_once $config['SiteClassPath']."class.watch.php";
	
	
	$Objwatch=new Watch();
	
	
	$ObjIndex=new Index();
	
	$ObjReg=new Register();
	
	$ObjReg->Get_Recent_mem();
	
	$ObjReg->Get_Country(); 
	
    $var=$_SERVER['REQUEST_URI'];

 	$tt=explode('/',$var);

	$expire=time()+60*60*24*30;
	
	setcookie("add_watch", $var, $expire);
	
	
	if($_POST['login']!='') 
	{
	$page="home";
	$ObjReg->Check_MemberLog($_REQUEST,$page);
	} 
	
	if($_REQUEST['product_id'] != '')
	{
	   
	  $Objwatch->add_watch_items();
	
	}
	
	
	
	if(isset($_REQUEST['Submit']))

			{

			  $Objwatch->delete_watchlist($_POST); 

			}
	
	$Objwatch->view_watch_items();
	
	
	$objSmarty->assign("ObjReg",$ObjReg); 
	$objSmarty->assign("ObjIndex",$ObjIndex);
	$objSmarty->assign("IncludeTpl", "watch_list.tpl");
	$objSmarty->display("pagetemplate.tpl"); 
	
?>