<?php 
	include "includes/common.php";
	$sql= new MysqlFns();
	
	extract($_REQUEST);
	
 $result1="select * from tbl_category where sub_parent_id='$motor_id' order by Make asc";
$exe=$sql->ExecuteQuery($result1,"select");
echo '<select id="mosub_category" name="mosub_category" class="dd" onchange="vali1();">
<option value="">Select Model</option>';
foreach($exe as $val){
echo "<option value=\"$val[category_id]\" >$val[model]</option>"; 
}
echo "</select>";

?>