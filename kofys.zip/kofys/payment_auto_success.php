<?php   
	
	include "includes/common.php";
	include_once $config['SiteClassPath']."class.Register.php";
	include $config['SiteClassPath']."class.split_page_results.php";
	include_once $config['SiteClassPath']."class.sell.php";
	$objSell=new sell();
	$cid=$_REQUEST['cid'];
	
	//$objSell->select_rvsmake();
	
	
	//$objSell->select_rvs_review();
	
	if($_REQUEST['cid']!=='')
	{
	$objSell->update_cars_status($cid);
	}
	$objSmarty->assign("cid",$cid);
	$objSmarty->assign("objSell",$objSell); 
	$objSmarty->assign("IncludeTpl", "payment_auto_success.tpl");	 
	$objSmarty->display("pagetemplate.tpl"); 
	
?>