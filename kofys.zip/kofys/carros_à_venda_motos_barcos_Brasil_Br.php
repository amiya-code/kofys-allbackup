<?php   
	
	include "includes/common.php";
	include_once $config['SiteClassPath']."class.sitemap.php";
	include $config['SiteClassPath']."class.split_page_results.php";
	$objsitemap = new sitemap;
	
    $objsitemap->carros_à_venda_motos_barcos_Brasil_Br();
	
	$objSmarty->assign("ObjReg",$ObjReg); 
	$objSmarty->assign("IncludeTpl", "carros_à_venda_motos_barcos_Brasil_Br.tpl");	 
	$objSmarty->display("pagetemplate.tpl"); 
	
?>