<?php   
	
	include "includes/common.php";
	include_once $config['SiteClassPath']."class.sitemap.php";
	include $config['SiteClassPath']."class.split_page_results.php";
	$objsitemap = new sitemap;
	
    $objsitemap->Used_Cars_in_South_Carolina();
	
	$objSmarty->assign("ObjReg",$ObjReg); 
	$objSmarty->assign("IncludeTpl", "Used_Cars_in_South_Carolina.tpl");	 
	$objSmarty->display("pagetemplate.tpl"); 
	
?>