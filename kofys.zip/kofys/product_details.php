<?php   
	
	include "includes/common.php";
	include_once $config['SiteClassPath']."class.Register.php";
	include $config['SiteClassPath']."class.split_page_results.php";
	include_once $config['SiteClassPath']."class.index.php";
 
	$ObjIndex=new Index();
	
	$ObjReg=new Register();
	
	$ObjReg->Get_Recent_mem();
	
	$ObjReg->Get_Country(); 
	$type=$_REQUEST['type'];
	
	if($_POST['login']!='') 
	{
	$page="home";
	$ObjReg->Check_MemberLog($_REQUEST,$page);
	} 
	
	if($_REQUEST['Find_auto_x'])
	{
	
	 $ObjIndex->Find_auto();
	 
	 }
	
	if($_REQUEST['product_id'] != ''){
	
	$ObjIndex->product_details();
	
	}
	
	
	if($_REQUEST['Send'] != ''){
	
		if(empty($_POST['fname'])){
			$captcha_error1  = "\n Please enter first name."; 
                $cap1 = "invalid1";
				$cfname = $_POST['fname'];
				$clname = $_POST['lname'];;
				$cemail = $_POST['email'];
				$cphone = $_POST['phone'];
				$czip = $_POST['zipcode'];
				$cmsg = $_POST['msg'];
                
		}else if(empty($_POST['lname'])){
			$captcha_error1  = "\n Please enter last name."; 
                $cap1 = "invalid1";
				$cfname = $_POST['fname'];
				$clname = $_POST['lname'];;
				$cemail = $_POST['email'];
				$cphone = $_POST['phone'];
				$czip = $_POST['zipcode'];
				$cmsg = $_POST['msg'];
                
		}else if(empty($_POST['email'])){
			$captcha_error1  = "\n Please enter email id."; 
                $cap1 = "invalid1";
				$cfname = $_POST['fname'];
				$clname = $_POST['lname'];;
				$cemail = $_POST['email'];
				$cphone = $_POST['phone'];
				$czip = $_POST['zipcode'];
				$cmsg = $_POST['msg'];
                
		}else if(!eregi("^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$", $_POST['email'])){
				$captcha_error1  = "\n Please enter valid email id."; 
                $cap1 = "invalid1";
				$cfname = $_POST['fname'];
				$clname = $_POST['lname'];;
				$cemail = $_POST['email'];
				$cphone = $_POST['phone'];
				$czip = $_POST['zipcode'];
				$cmsg = $_POST['msg'];

			}else if(empty($_POST['phone'])){
				$captcha_error1  = "\n Please enter phone."; 
                $cap1 = "invalid1";
				$cfname = $_POST['fname'];
				$clname = $_POST['lname'];;
				$cemail = $_POST['email'];
				$cphone = $_POST['phone'];
				$czip = $_POST['zipcode'];
				$cmsg = $_POST['msg'];

			}else if(empty($_POST['zipcode'])){
				$captcha_error1  = "\n Please enter zipcode."; 
                $cap1 = "invalid1";
				$cfname = $_POST['fname'];
				$clname = $_POST['lname'];;
				$cemail = $_POST['email'];
				$cphone = $_POST['phone'];
			echo	$czip = $_POST['zipcode'];exit;
				$cmsg = $_POST['msg'];

			}else if(empty($_SESSION['6_letters_code'] ) || strcmp($_SESSION['6_letters_code'], $_POST['6_letters_code']) != 0)
	{
	//Note: the captcha code is compared case insensitively.
	//if you want case sensitive match, update the check above to
	// strcmp()
	//alert('gdfhsf');
		$captcha_error1  = "\n The verification code does not match!"; 
                $cap1 = "invalid1";
				$cfname = $_POST['fname'];
				$clname = $_POST['lname'];;
				$cemail = $_POST['email'];
				$cphone = $_POST['phone'];
				$czip = $_POST['zipcode'];
				$cmsg = $_POST['msg'];
				
                
        }
		else{
			
		$ObjIndex->send_mail();
		
		$ObjIndex->insert_notification($_POST);
		
		
		}
	
	}
	
	$ObjIndex->view_product_images();
	
	$ObjIndex->Year(); 
	
	$ObjIndex->select_Category();
	
	if($_REQUEST['submit'] != ''){
			if(empty($_POST['offer'])){
			$captcha_error  = "\n Please enter offer"; 
                $cap = "invalid";
				$currency = $_POST['currency'];
				$offer = $_POST['offer'];
				$fname = $_POST['first_name'];
				$lname = $_POST['last_name'];
				//$fname = $_POST['first_name'];
				$makephone = $_POST['phone'];
				$email = $_POST['email_id'];
				$tframe = $_POST['DropDownListTimeFrame'];
				$comments = $_POST['enquiry'];
                
		}else if(empty($_POST['first_name'])){
			$captcha_error  = "\n Please enter first name"; 
                $cap = "invalid";
				$currency = $_POST['currency'];
				$offer = $_POST['offer'];
				$fname = $_POST['first_name'];
				$lname = $_POST['last_name'];
				//$fname = $_POST['first_name'];
				$makephone = $_POST['phone'];
				$email = $_POST['email_id'];
				$tframe = $_POST['DropDownListTimeFrame'];
				$comments = $_POST['enquiry'];
                
		}else if(empty($_POST['last_name'])){
			$captcha_error  = "\n Please enter last name"; 
                $cap = "invalid";
				$currency = $_POST['currency'];
				$offer = $_POST['offer'];
				$fname = $_POST['first_name'];
				$lname = $_POST['last_name'];
				//$fname = $_POST['first_name'];
				$makephone = $_POST['phone'];
				$email = $_POST['email_id'];
				$tframe = $_POST['DropDownListTimeFrame'];
				$comments = $_POST['enquiry'];
                
		}else if(empty($_POST['email_id'])){
			$captcha_error  = "\n Please enter email id"; 
                $cap = "invalid";
				$currency = $_POST['currency'];
				$offer = $_POST['offer'];
				$fname = $_POST['first_name'];
				$lname = $_POST['last_name'];
				//$fname = $_POST['first_name'];
				$makephone = $_POST['phone'];
				$email = $_POST['email_id'];
				$tframe = $_POST['DropDownListTimeFrame'];
				$comments = $_POST['enquiry'];
                
		}else if(!eregi("^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$", $_POST['email_id'])){
				$captcha_error  = "\n Please enter valid email id"; 
                $cap = "invalid";
				$currency = $_POST['currency'];
				$offer = $_POST['offer'];
				$fname = $_POST['first_name'];
				$lname = $_POST['last_name'];
				//$fname = $_POST['first_name'];
				$makephone = $_POST['phone'];
				$email = $_POST['email_id'];
				$tframe = $_POST['DropDownListTimeFrame'];
				$comments = $_POST['enquiry'];

			}else if(empty($_SESSION['6_letters_code'] ) || strcmp($_SESSION['6_letters_code'], $_POST['6_letters_code']) != 0)
			{
	//Note: the captcha code is compared case insensitively.
	//if you want case sensitive match, update the check above to
	// strcmp()
		$captcha_error  = "\n The verification code does not match!"; 
                $cap = "invalid";
				$currency = $_POST['currency'];
				$offer = $_POST['offer'];
				$fname = $_POST['first_name'];
				$lname = $_POST['last_name'];
				//$fname = $_POST['first_name'];
				$makephone = $_POST['phone'];
				$email = $_POST['email_id'];
				$tframe = $_POST['DropDownListTimeFrame'];
				$comments = $_POST['enquiry'];
                
        }else{
	$ObjReg->insert_offer($_POST);
	$offer_msg="Congratultions! Your offer has been successfully sent to the seller, expect a response within 24hr.";
	$objSmarty->assign("offer_msg",$offer_msg); 
		}
	}
 
	$objSmarty->assign("cfname",$cfname); 
	$objSmarty->assign("clname",$clname); 
	$objSmarty->assign("cemail",$cemail); 
	$objSmarty->assign("cphone",$cphone); 
	$objSmarty->assign("czip",$czip); 
	$objSmarty->assign("cmsg",$cmsg); 
	
	$objSmarty->assign("currency",$currency);
	$objSmarty->assign("offer",$offer); 
	$objSmarty->assign("fname",$fname); 
	$objSmarty->assign("lname",$lname); 
	$objSmarty->assign("email",$email); 
	$objSmarty->assign("makephone",$makephone); 
	$objSmarty->assign("tframe",$tframe); 
	$objSmarty->assign("comments",$comments); 

	$objSmarty->assign("captcha_error",$captcha_error); 
	$objSmarty->assign("cap",$cap); 
	$objSmarty->assign("captcha_error1",$captcha_error1); 
	$objSmarty->assign("cap1",$cap1); 
	$objSmarty->assign("type",$type);
	$objSmarty->assign("ObjReg",$ObjReg); 
	$objSmarty->assign("ObjIndex",$ObjIndex); 
	$objSmarty->assign("IncludeTpl", "product_details.tpl");	 
	$objSmarty->display("pagetemplate.tpl"); 
	
?>