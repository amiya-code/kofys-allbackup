<?php   
	
	include "includes/common.php";
	include_once $config['SiteClassPath']."class.sitemap.php";
	include $config['SiteClassPath']."class.split_page_results.php";
	$objsitemap = new sitemap;
	
	$objsitemap->Cars_for_sale_boats_motorcycles_rvs_west_Virgina_WV();
	
	$objSmarty->assign("ObjReg",$ObjReg); 
	$objSmarty->assign("IncludeTpl", "Cars_for_sale_boats_motorcycles_rvs_west_Virgina_WV.tpl");	 
	$objSmarty->display("pagetemplate.tpl"); 
	
?>