<?php   
	
	include "includes/common.php";
	include_once $config['SiteClassPath']."class.Content.php";
	include $config['SiteClassPath']."class.split_page_results.php";
	$objcon=new Content();
	
	$objcon->select_priceguide();
	
	//$objSmarty->assign("ObjReg",$ObjReg); 
	$objSmarty->assign("IncludeTpl", "buy_priceguide.tpl");	 
	$objSmarty->display("pagetemplate.tpl"); 
	
?>