<?php   
	include "includes/common.php";
	//include_once $config['SiteClassPath']."class.Register.php";
	include $config['SiteClassPath']."class.split_page_results.php";
	include_once $config['SiteClassPath']."class.index.php";
	
	$ObjIndex=new Index();
	ini_set('memory_limit', '1000M');
	@set_time_limit(0);
	
	
	if($_POST['login']!='') 
	{
		$page="home";
		$ObjReg->Check_MemberLog($_REQUEST,$page);
	} 
	
	//pr($_REQUEST);
	
	$zipcode=$_REQUEST['zipcode'];
	$city=$_REQUEST['city'];
	$category=$_REQUEST['category'];
	$sub_category=$_REQUEST['sub_category'];
	$body_style=$_REQUEST['body_Style']; 
	$motortype=$_REQUEST['body_style'];
	
	if($_REQUEST['model']){
		$model = $_REQUEST['model'];
	}else{
		$model = '';
	}
	if(!empty($_REQUEST['pricefrom'])){
		$pricefrom=$_REQUEST['pricefrom'];
	}else{
		$pricefrom=0;
	}
	if(!empty($_REQUEST['priceto'])){
		$priceto= $_REQUEST['priceto'];
	}else{
		$priceto=75000;
	}
	
	if(!empty($_REQUEST['year_from'])){
		$year_from=$_REQUEST['year_from'];
	}else{
		
		$year_from='1976';
	}
	if(!empty($_REQUEST['year_to'])){
		$year_to= $_REQUEST['year_to'];
	}else{
		$year_to= date('Y');
	}
	
	//$year_from=$_REQUEST['year_from'];
	//$year_to= $_REQUEST['year_to'];
	$ObjIndex->select_Category();
	$distance=$_REQUEST['distance']; 
	$sub_category=$_REQUEST['sub_category']; 
	$conditions = $_REQUEST['conditions'];
	$price_range = $_REQUEST['price_range'];
	$limit = $_REQUEST['limit'];
	
	//print_r($_REQUEST);die;
	
	if($_REQUEST['Find_auto_x'] != '' || $_REQUEST['search_x']!='')	{
		//echo 'hi'; die;		
		$ObjIndex->Find_auto();
		
	}
	
	//echo $_REQUEST['year_to'];
	if($_REQUEST['search_x'] || $_REQUEST['sort'] != '' || $_REQUEST['price'] != '' || $_REQUEST['mileage'] != '' || $_REQUEST['limit'] != ''  || $_REQUEST['body_style'] != '' || $_REQUEST['location'] != ''){
		//pr("lsfdf");die; 
		//$ObjIndex->Find_auto();
		$ObjIndex->search_result_auto();
		
	}
	
	$body_styles = array('Convertible','Coupe','Hatchback');
	
	//$ObjIndex->Year();
	//pr($_REQUEST);die;
	
	//pr($_REQUEST);die;
	
	//$ObjIndex->select_Boat();
	
	//$ObjIndex->select_Motor();
	
	//$ObjIndex->select_Rvs();
	
	
	//$ObjIndex->rvstype();
	
	$ObjIndex->select_countModel('1');
	
	
	//$objcaryear->select_caryear();
	$objSmarty->assign("model",$model); 
	$objSmarty->assign("limit",$limit); 
	$objSmarty->assign("conditions",$conditions); 
	$objSmarty->assign("sub_category",$sub_category); 
	$objSmarty->assign("distance",$distance); 
	$objSmarty->assign("zipcode",$zipcode); 
	$objSmarty->assign("city",$city); 
	
	$milefrom=$_REQUEST['milefrom'];
	$mileto=$_REQUEST['mileto'];
	$objSmarty->assign("milefrom",$milefrom);
	$objSmarty->assign("mileto",$mileto);
	
	$objSmarty->assign("category",$category); 
	$objSmarty->assign("sub_category",$sub_category); 
	$objSmarty->assign("body_style",$body_style);
	$objSmarty->assign("motortype",$motortype); 
	$objSmarty->assign("year_from",$year_from); 
	$objSmarty->assign("year_to",$year_to); 
	$objSmarty->assign("pricefrom",$pricefrom); 
	$objSmarty->assign("priceto",$priceto); 
	$objSmarty->assign("ObjReg",$ObjReg); 
	$objSmarty->assign("price_range",$price_range); 	
	$objSmarty->assign("ObjIndex",$ObjIndex);
	$objSmarty->assign("IncludeTpl", "search_result.tpl");
	$objSmarty->display("pagetemplate.tpl"); 
	
?>