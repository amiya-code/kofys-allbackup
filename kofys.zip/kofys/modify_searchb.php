<?php   
	
	include "includes/common.php";
	include_once $config['SiteClassPath']."class.Register.php";
	include $config['SiteClassPath']."class.split_page_results.php";
	include_once $config['SiteClassPath']."class.index.php";
	
	
	$ObjIndex=new Index();
	
	$ObjReg=new Register();
	
	$ObjReg->Get_Recent_mem();
	
	$ObjReg->Get_Country(); 
	
	
	
	$zipcode=$_REQUEST['zipcode'];
	$boattype=$_REQUEST['boattype'];
	$bosub_category=$_REQUEST['bosub_category'];
	$byear_from=$_REQUEST['byear_from'];
	$byear_to= $_REQUEST['byear_to'];
	$distance=$_REQUEST['distance'];
	$sub_category=$_REQUEST['sub_category']; 
	$conditions = $_REQUEST['conditions'];
	
	if($_POST['login']!='') 
	{
	$page="home";
	$ObjReg->Check_MemberLog($_REQUEST,$page);
	} 
	
	
	
	$ObjIndex->Year();
	
	//print_r($_REQUEST); echo '<pre>';
	
	
	//$sele = "select * from tbl_category where sub_parent_id = '".."'";
	
	$page_url=$_SERVER['REQUEST_URI'];

	$ObjIndex->select_boatcategory();
	$objSmarty->assign("zipcode",$zipcode); 
	$objSmarty->assign("boattype",$boattype); 
	$objSmarty->assign("bosub_category",$bosub_category); 
	$objSmarty->assign("byear_from",$byear_from); 
	$objSmarty->assign("byear_to",$byear_to); 
	$objSmarty->assign("distance",$distance); 
	$objSmarty->assign("conditions",$conditions); 
	$objSmarty->assign("ObjReg",$ObjReg); 
	$objSmarty->assign("ObjIndex",$ObjIndex); 	
	$objSmarty->assign("page_url",$page_url);
	//$objSmarty->assign("IncludeTpl", "search_boat.tpl");
	$objSmarty->display("modify_searchb.tpl"); 
	
?>