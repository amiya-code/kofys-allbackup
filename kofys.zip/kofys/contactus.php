<?php   
	
	include "includes/common.php";
	include_once $config['SiteClassPath']."class.Register.php";
	include $config['SiteClassPath']."class.split_page_results.php";
	include_once $config['SiteClassPath']."class.index.php";
	$objcontact = new Register;
	$ObjIndex=new Index();
	
	if($_REQUEST['submit'])
	{
		if(empty($_POST['name'])){
			$captcha_error  = "\n Please enter name."; 
               $cap = "invalid";
				$contactname =  $_REQUEST['name'];	 
				$contactemail =  $_REQUEST['email'];
				$contactsubject =  $_REQUEST['subject'];
				$contactmsg =  $_REQUEST['message'];
                
		}else if(empty($_POST['email'])){
			$captcha_error  = "\n Please enter email id."; 
                $cap = "invalid";
				$contactname =  $_REQUEST['name'];	 
				$contactemail =  $_REQUEST['email'];
				$contactsubject =  $_REQUEST['subject'];
				$contactmsg =  $_REQUEST['message'];
		}else if(!eregi("^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$", $_POST['email'])){
				$captcha_error  = "\n Please enter valid email id."; 
                $cap = "invalid";
				$contactname =  $_REQUEST['name'];	 
				$contactemail =  $_REQUEST['email'];
				$contactsubject =  $_REQUEST['subject'];
				$contactmsg =  $_REQUEST['message'];

			}else if(empty($_POST['subject'])){
				$captcha_error  = "\n Please enter subject."; 
                $cap = "invalid";
				$contactname =  $_REQUEST['name'];	 
				$contactemail =  $_REQUEST['email'];
				$contactsubject =  $_REQUEST['subject'];
				$contactmsg =  $_REQUEST['message'];

			}else if(empty($_POST['message'])){
				$captcha_error  = "\n Please enter message."; 
                $cap = "invalid";
				$contactname =  $_REQUEST['name'];	 
				$contactemail =  $_REQUEST['email'];
				$contactsubject =  $_REQUEST['subject'];
				$contactmsg =  $_REQUEST['message'];

			}else if(empty($_SESSION['6_letters_code'] ) || strcmp($_SESSION['6_letters_code'], $_POST['6_letters_code']) != 0)
	{
	//Note: the captcha code is compared case insensitively.
	//if you want case sensitive match, update the check above to
	// strcmp()
	//alert('gdfhsf');
		$captcha_error  = "\n The verification code does not match!"; 
                $cap = "invalid";
				$contactname =  $_REQUEST['name'];	 
				$contactemail =  $_REQUEST['email'];
				$contactsubject =  $_REQUEST['subject'];
				$contactmsg =  $_REQUEST['message'];      
        }else{
	
	$ObjIndex->contact_us2();
		}
	
	}
	
	$objSmarty->assign("contactname",$contactname); 
	$objSmarty->assign("contactemail",$contactemail); 
	$objSmarty->assign("contactsubject",$contactsubject); 
	$objSmarty->assign("contactmsg",$contactmsg); 
	$objSmarty->assign("captcha_error",$captcha_error); 
	$objSmarty->assign("cap",$cap); 

	$objSmarty->assign("objcontact",$ObjReg); 
	$objSmarty->assign("IncludeTpl", "contact_us.tpl");	 
	$objSmarty->display("pagetemplate.tpl"); 
	
?>