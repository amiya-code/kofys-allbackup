<?php   
	
	include "includes/common.php";
	include_once $config['SiteClassPath']."class.sitemap.php";
	include $config['SiteClassPath']."class.split_page_results.php";
	$objsitemap = new sitemap;
	
	$objsitemap->used_vehicles_for_sale_by_owner();
	
	$objSmarty->assign("ObjReg",$ObjReg); 
	$objSmarty->assign("IncludeTpl", "used_vehicles_for_sale_by_owner.tpl");	 
	$objSmarty->display("pagetemplate.tpl"); 
	
?>