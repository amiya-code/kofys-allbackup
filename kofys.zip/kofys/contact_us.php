<?php   
	
	include "includes/common.php";
	include_once $config['SiteClassPath']."class.Register.php";
	include $config['SiteClassPath']."class.split_page_results.php";
	include_once $config['SiteClassPath']."class.index.php";
	
	include_once $config['SiteClassPath']."class.watch.php";
	
	
	$Objwatch=new Watch();
	
	
	$ObjIndex=new Index();
	
	
	$ObjReg=new Register();
	
	
	$ObjReg->Get_Recent_mem();
	
	
	$ObjReg->Get_Country(); 
	
	
	if($_REQUEST['Send'] != ''){
	
	
	$ObjIndex->contact_us();
	
	}
    
	
	$objSmarty->assign("ObjReg",$ObjReg); 
	$objSmarty->assign("ObjIndex",$ObjIndex);
	$objSmarty->display("contact.tpl");
	//$objSmarty->display("pagetemplate.tpl"); 
	
?>