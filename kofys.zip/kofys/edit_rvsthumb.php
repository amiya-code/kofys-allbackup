<?php   
	
	include "includes/common.php";
	include_once $config['SiteClassPath']."class.Register.php";
	include $config['SiteClassPath']."class.split_page_results.php";
	include_once $config['SiteClassPath']."class.sell.php";
	$objSell=new sell();
	$objReg=new Register();
	
	$objReg->LoginCheck();
	
	$var=$_SERVER['REQUEST_URI'];
	
 	$tt=explode('/',$var);
	
	$expire=time()+60*60*24*30;
	setcookie("sellcars", $var, $expire);
	
	$objSell->Year();
	
	$cid = $_REQUEST['cid'];
	
	//$objSell->select_edit_rvs();
	
	//$objSell->select_rvsmake();
	
	if($_REQUEST['submit']=='Update')
	{
		header("location:rvs_review.php?cid=".$_REQUEST['cid']."");
	}
	
	
	if($_REQUEST['delid'])
	{
		$DelQuery = "Delete from tbl_images where image_id=".$_REQUEST['delid'];
		$objSell->ExecuteQuery($DelQuery,"delete");
		header("location:edit_rvsthumb.php?cid=$cid");
	}
	if($_REQUEST['submit']=='Upload')
	{
		$photo_name = $_FILES['photo1']['name'];
		
		$rr = explode(".",$photo_name);
		
		$Temp_ty = $rr[1];
		
		$t="";
		
		if( $_FILES['photo1']['size'] >0 )
	
	{ 
	$fileSavePath1="store_img/full_images/";	
	$fileSavePath="store_img/thumb_images/";	
	list($width, $height, $type, $attr) = getimagesize($_FILES['photo1']['tmp_name']);
	if($height >=100 )
	{
	$resizeImg=180;
	$resizeImg1=200;
	}
	else
	{
	$resizeImg=90;
	$resizeImg1=200;
	}
	
	/*elseif($height > 900 || $width > 900)
	{&& $height <= 900
	echo "2".$resizeImg=800;
	echo "<br>2".$resizeImg1=600;
	}*/
	
	
	
	$keepOriginal=true;
	
	
	
	function resize_img($pathimage, $new_sizex, $new_sizey, $dest_file,$ext) 
	
	{
	
	$imagename = $pathimage;
	
	if(file_exists($pathimage)) 
	
	{
	
	switch ($ext)
	
	{
	
	case '.jpg':
	$pic = imagecreatefromjpeg($pathimage); 
	break;
	
	case '.gif':
	$pic = imagecreatefromgif($pathimage); 
	break;
	
	case '.png':
	$pic = imagecreatefrompng($pathimage); 
	break;							
	
	}
	
	$sizex = imagesx($pic) ;
	
	$sizey = imagesy($pic) ;
	
	if (($sizex > $new_sizex) || ($sizey > $new_sizey) ) 
	
	{
	
	if($sizex>$sizey) 
	
	{ 
	
	$s0x = $new_sizex ;
	
	$s0y = (($new_sizex * $sizey)/$sizex) ;
	
	settype ($s0y, "integer")  ;
	
	}  
	
	else
	
	if ($sizex<$sizey) 
	
	{
	
	$s0y = $new_sizey ;
	
	$s0x = (($new_sizey * $sizex)/$sizey) ;
	
	settype ($s0x, "integer")  ;
	
	} else 
	
	{
	
	$s0x = $new_sizex ;
	
	$s0y = $new_sizey ;
	
	}
	
	$gd_info=gd_info();
	
	if(strstr($gd_info['GD Version'],"2.")) ///mmmmmmhhh....... 
	
	{
	
	$out = imagecreatetruecolor( $s0x, $s0y) ;
	
	imagecopyresampled ($out, $pic, 0, 0, 0, 0, $s0x, $s0y, $sizex, $sizey) ;
	
	}else 
	
	{
	
	$out = imagecreate( $s0x, $s0y) ;
	
	imagecopyresized($out, $pic, 0, 0, 0, 0, $s0x, $s0y, $sizex, $sizey) ;
	
	}
	
	switch ($ext)
	
	{
	
	case '.jpg':$pic = imagejpeg($out, $dest_file,100); break;
	
	case '.gif':$pic = imagegif($out, $dest_file) ; break;
	
	case '.png':$pic = imagepng($out, $dest_file) ; break;							
	
	}
	
	imagedestroy($out); 
	
	return 1 ;
	
	} else //
	
	{
	
	copy($pathimage, $dest_file) ;
	
	return 1;
	
	}
	
	} else //!file_exists
	
	{
	
	return 0 ;
	
	}
	
	}
	
	foreach ($_FILES as $nome=>$file)//copia fisica dei file per evitare upload inutili
	
	{
	
	if (!$file['size']>0) continue;	
	
	$file['name']=str_replace(array('"',"'"," "),"_",stripslashes($file['name'])); //sostituisce i caratteri non ammessi con _
	
	
	
	$t=time()."_".$file['name'];
	
	$ext=strtolower(substr($file['name'],(strlen($file['name'])-4),4)); //prende le ultime 4 lettere
	
	
	
	if ($resizeImg && ($ext==".gif" || $ext==".jpg" || $ext==".png"))
	
	{
	
	resize_img($file['tmp_name'],$resizeImg,$resizeImg,$fileSavePath."/".$t,$ext);
	
	resize_img($file['tmp_name'],$resizeImg1,$resizeImg1,$fileSavePath."/".$t,$ext);
	
	
	
	}
	
	if($height > 800 || $width > 600)
	{
	$resizeImg=500;
	$resizeImg1=400;
	resize_img($file['tmp_name'],$resizeImg,$resizeImg,$fileSavePath."/".$t,$ext);
	copy($file['tmp_name'],$fileSavePath1."/".$t);
	$add = $fileSavePath1."/".$t;
	chmod("$add",0777); 
	}
	else
	{
	if (($resizeImg && $keepOriginal) || !$resizeImg) copy($file['tmp_name'],$fileSavePath."/".$t);
	copy($file['tmp_name'],$fileSavePath1."/".$t);
	$add = $fileSavePath1."/".$t;
	chmod("$add",0777); 
	}	
	
	}	
	
	}
	
	
	$insqry="insert into tbl_images (image_cat,image_pid,image_mid,image,date,status) values ('".$cid."','".$cid."','".$_SESSION['userid']."','".$t."',now(),1)";
	
	
	$res_que = mysql_query($insqry);
	
	
	//$ObjReg->upload_img($pid);
	}
	
	$objSell->select_rvs_thumb();
	
	$objSmarty->assign("cid",$cid);
	$objSmarty->assign("ObjReg",$ObjReg); 
	$objSmarty->assign("IncludeTpl", "edit_rvsthumb.tpl");	 
	$objSmarty->display("pagetemplate.tpl"); 
	
	?>	