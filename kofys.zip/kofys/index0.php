<?php  	
  ini_set('display_errors', 0);
ini_set('display_startup_errors', 0);
error_reporting(-1);
/*	Debug control for smarty template please comment these lines before uploading*/
//########################################################################
//########################################################################

//$smarty->debugging = TRUE;
//########################################################################
//########################################################################
	
	
	
	include "includes/common.php";
	//echo "s,dfhskdfn";die;
	//pr("fhekfjkd");
	include_once $config['SiteClassPath']."class.Register.php";
	include $config['SiteClassPath']."class.split_page_results.php";
	include_once $config['SiteClassPath']."class.sitemap.php";
	include_once $config['SiteClassPath']."class.index.php";
	include_once $config['SiteClassPath']."class.review.php";
	include_once $config['SiteClassPath']."class.Content.php";
	include_once $config['SiteClassPath']."class.car_year.php";
	/***************For date difference***************/
	$date = date("Y-m-d");
	$date_timestamp = strtotime($date);
	$expire_date = strtotime("+3 months", $date_timestamp);

	"Expire Date = ".date("Y-m-d", $expire_date);
	/***************For date difference***************/
    //header('Content-Type: image/jpg');
	$objcon=new Content();
	
	$objcaryear=new caryear();

	$objcon->select_resources();
	
	$objcon->select_articles();
	
	$objcon->select_priceguide();
	
// code to fetch home page text content and meta detail  ! start !	
	
	$objsitemap = new sitemap;
	
	$objsitemap->HOMEPAGE();
	
	

//  ! END !

//#######################################	
//
//Assign Body_style

	$sql = "SELECT DISTINCT body_style FROM tbl_category ORDER BY body_style DESC";
	$sqlObj	= new MysqlFns();
	$result			= $sqlObj->ExecuteQuery($sql, "select");
	//$result = mysqli_query($sql) or die('Query failed.');
	/* while($row = mysql_fetch_array($result))
	{
	$body_style[]=ucwords($row['body_style']);
	} */
	//pr($result);
	foreach($result as $row){
		if(!empty($row['body_style'])){
			$body_style[$row['body_style']]=ucwords($row['body_style']); 
		}		
	}
	//pr($body_style);die;
	
	$objSmarty->assign('items',$body_style);
	
//########################################	
	
	$imgsql = "select image_name from tbl_banners where 1=1";
	$result	= $sqlObj->ExecuteQuery($imgsql, "select");
	//pr($result);die;
	$img=0;
	foreach($result as $value){
		++$img;
		if($img==1){
			$image1 = $value['image_name'];
		}else if($img==2){
			$image2 = $value['image_name'];
		}else if($img==3){
			$image3 = $value['image_name'];
		}else if($img==4){
			$image4 = $value['image_name'];
		}else if($img==5){
			$image5 = $value['image_name'];
		}
	}

	$objSmarty->assign("image1",$image1);	
	$objSmarty->assign("image2",$image2);	
	$objSmarty->assign("image3",$image3);	
	$objSmarty->assign("image4",$image4);	
	$objSmarty->assign("image5",$image5);	

	$objreview = new review();
	
	$ObjIndex=new Index();
	
	$ObjReg=new Register();
	
	$ObjReg->Get_Recent_mem();
	
	$ObjReg->Get_Country();
	
	$objreview->select_cars_Make();
	
	//$objreview->Year(); 
	
	
	if($_POST['login']!='') 
	{
	
	$page="home"; 
	
	$ObjReg->Check_MemberLog($_REQUEST,$page);
	
	} 
	
	
	
	if(($_REQUEST['make'] && $_REQUEST['year'])!=='')
	{
	  $objreview->select_cars_review();
	}	

	
	if($_REQUEST['Find_auto_x'])
	{
	
	 $ObjIndex->Find_auto();	 
	 }
	 
	 
	
	
	
	if($_REQUEST['review_x'] != '')
	{
	   
	 $objreview->review_details();
	
	}
	
	if($_REQUEST['activation']=='Active')
	{	
		
		$SelQu = "select  * from tbl_member where id='".$_REQUEST['maxid']."'";
		$SelF=$ObjReg->ExecuteQuery($SelQu, "select");
		$total=count($SelF);
		if($total!=0)
		{
	    $SelQuery = "select  * from tbl_member where id='".$_REQUEST['maxid']."' and status = 1";
		$SelFrid=$ObjReg->ExecuteQuery($SelQuery, "select");
		
	     $Total=count($SelFrid);
		 
		 if($Total==0) {
	
	 			$query = "update tbl_member set status=1 where id ='".$_REQUEST['maxid']."'";
	 			$result =$ObjReg->ExecuteQuery($query,"update");				 
		  }
		  else
		  {
		    $objSmarty->assign("msg","Already Activated");
		  }
		   }
		  else
		  {
		    $objSmarty->assign("msg","User not Exist");
		  }
	}
	if(isset($_POST) && !empty($_POST))
	{
		
		$ObjIndex->send_contactmail();
	}
	
	$ObjIndex->Year();
	
	$ObjIndex->select_Category();

	
	$objcaryear->select_caryear();

	$objSmarty->assign("ObjReg",$ObjReg); 
	$objSmarty->assign("IncludeTpl", "index.tpl");	 
	$objSmarty->display("pagetemplate.tpl"); 

	
?>