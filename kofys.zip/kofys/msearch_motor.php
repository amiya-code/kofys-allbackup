<?php   
	
	include "includes/common.php";
	include_once $config['SiteClassPath']."class.Register.php";
	include $config['SiteClassPath']."class.split_page_results.php";
	include_once $config['SiteClassPath']."class.index.php";
	
	
	
	$ObjIndex=new Index();
	
	$ObjReg=new Register();
	
	$ObjReg->Get_Recent_mem();
	
	$ObjReg->Get_Country(); 
	
	 @set_time_limit(0);
	
	$zipcode=$_REQUEST['zipcode'];
	$motors=$_REQUEST['motors'];
	$mosub_category=$_REQUEST['mosub_category'];
	$body_style=$_REQUEST['body_Style'];
	$myear_from=$_REQUEST['myear_from'];
	$myear_to= $_REQUEST['myear_to'];
	$distance=$_REQUEST['distance']; 
	$mosub_category=$_REQUEST['mosub_category']; 
	$conditions = $_REQUEST['conditions'];
	$limit = $_REQUEST['limit'];
	
	if($_POST['login']!='') 
	{
	$page="home";
	$ObjReg->Check_MemberLog($_REQUEST,$page);
	} 
	
	
	
	 if($_REQUEST['Find_motor_x'] != ''){
	
	 $ObjIndex->Find_motor();
	 
	 }
	 
	/*if($_REQUEST['sort']=='1')
	{
	//echo ">>>>>>>>>>>>>";
	$ObjIndex->Find_motor_sort_asc();
	}
	if($_REQUEST['sort']=='2')
	{
	//echo ">>>>>>>>>>>>>";
	$ObjIndex->Find_motor_sort_desc();
	}*/
	
	
	
	
	
	//$ObjIndex->Year();
	
	
	if($_REQUEST['search_x'] || $_REQUEST['sort'] != '' || $_REQUEST['price'] != '' || $_REQUEST['mileage'] != '' || $_REQUEST['limit'] != '' || $_REQUEST['myear_from'] != '' || $_REQUEST['myear_to'] != ''){
	
	 $ObjIndex->search_result_motor(); 
	
	}

	
	
	$ObjIndex->Year();
	
	$ObjIndex->select_Motor123();
	
	if($_REQUEST['search_x']){
	
	 $ObjIndex->search_result_motor();
	
	}
	
	$objSmarty->assign("limit",$limit); 
	$objSmarty->assign("conditions",$conditions); 
	$objSmarty->assign("mosub_category",$mosub_category); 
	$objSmarty->assign("distance",$distance); 
	$objSmarty->assign("zipcode",$zipcode); 
	$objSmarty->assign("motors",$motors); 
	$objSmarty->assign("mosub_category",$mosub_category); 
	$objSmarty->assign("body_style",$body_style); 
	$objSmarty->assign("myear_from",$myear_from); 
	$objSmarty->assign("myear_to",$myear_to); 
	$objSmarty->assign("ObjIndex",$ObjIndex);
	$objSmarty->assign("ObjReg",$ObjReg); 
	$objSmarty->assign("IncludeTpl", "search_motorm.tpl");
	$objSmarty->display("pagetemplate.tpl"); 
	
?>