<?php   
	
	include "includes/common.php";
	include_once $config['SiteClassPath']."class.Register.php";
	include $config['SiteClassPath']."class.split_page_results.php";
	include_once $config['SiteClassPath']."class.index.php";
	
	
	$ObjIndex=new Index();
	
	$ObjReg=new Register();
	
	$ObjReg->Get_Recent_mem();
	
	$ObjReg->Get_Country(); 
	
	 @set_time_limit(0);
	
	$zipcode=$_REQUEST['zipcode'];
	$boattypes=$_REQUEST['boattypes'];
	$bosub_category=$_REQUEST['bosub_category'];
	$byear_from=$_REQUEST['byear_from'];
	$byear_to= $_REQUEST['byear_to'];
	$distance=$_REQUEST['distance'];
	$sub_category=$_REQUEST['sub_category']; 
	$conditions = $_REQUEST['conditions'];
	$limit = $_REQUEST['limit'];
	
	if($_POST['login']!='') 
	{
	$page="home";
	$ObjReg->Check_MemberLog($_REQUEST,$page);
	} 
	
	
	
	if($_REQUEST['Find_boat_x'] != '')
	{
	
	 $ObjIndex->Find_boat();
	 
	 }
	if($_REQUEST['sort']=='1')
	{
	//echo ">>>>>>>>>>>>>";
	$ObjIndex->Find_boat_sort_asc();
	}
	if($_REQUEST['sort']=='2')
	{
	//echo ">>>>>>>>>>>>>";
	$ObjIndex->Find_boat_sort_desc();
	}
	
	$ObjIndex->Year();
	
	
	if($_REQUEST['search_x'] || $_REQUEST['sort'] != '' || $_REQUEST['price'] != '' || $_REQUEST['mileage'] != '' || $_REQUEST['limit'] != '' || $_REQUEST['byear_from'] != '' || $_REQUEST['byear_to'] != ''){
	
	 $ObjIndex->search_result_boat();
	
	}
	
	//print_r($_REQUEST); echo '<pre>';
	
	
	//$sele = "select * from tbl_category where sub_parent_id = '".."'";
	
	
	$ObjIndex->select_boatcategory();
	
	$objSmarty->assign("limit",$limit); 
	$objSmarty->assign("zipcode",$zipcode); 
	$objSmarty->assign("boattypes",$boattypes); 
	$objSmarty->assign("bosub_category",$bosub_category); 
	$objSmarty->assign("byear_from",$byear_from); 
	$objSmarty->assign("byear_to",$byear_to); 
	$objSmarty->assign("distance",$distance); 
	$objSmarty->assign("conditions",$conditions); 
	$objSmarty->assign("ObjReg",$ObjReg); 
	$objSmarty->assign("ObjIndex",$ObjIndex); 	
	$objSmarty->assign("IncludeTpl", "search_boatm.tpl");
	$objSmarty->display("pagetemplate.tpl"); 
	
?>