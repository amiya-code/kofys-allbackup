<?php
if(mail("ankur@braintechnosys.com", "Test Subject", "Test Message")) {
echo 'sent';
}else{
 echo 'Not sent: <pre>'.print_r(error_get_last(), true).'</pre>';
}

$from = "ankur@braintechnosys.com";
$xheaders = "X-Mailer: PHP\n";
$xheaders .="From:".$from ."\n";
//$xheaders .= "Bcc: <" . $bcc . ">\n";
$xheaders .= "Content-Type: text/html; charset=iso-8859-1\n";
if(mail("ankur@braintechnosys.com", "Test Subject", "Test Message",$xheaders)) {
echo 'sent';
}else{
 echo 'Not sent: <pre>'.print_r(error_get_last(), true).'</pre>';
}
?>

<?php echo  getcwd(); echo "<br/>";
$ffmpeg = trim(shell_exec('which ffmpeg')); // or better yet:
$ffmpeg = trim(shell_exec('type -P ffmpeg'));
//echo $ffmpeg;echo "<br/>";
/*if (empty($ffmpeg))
{
    die('ffmpeg not available');
}else{
  echo 'ffmpeg available';
}*/
echo "<br/>";
echo phpinfo();

?>