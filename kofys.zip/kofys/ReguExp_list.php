<?php  	
	include "includes/common.php";
	include_once $config['SiteClassPath']."class.Register.php";
	include $config['SiteClassPath']."class.split_page_results.php";
	include_once $config['SiteClassPath']."class.index.php";
	include_once $config['SiteClassPath']."class.review.php";
	include_once $config['SiteClassPath']."class.Content.php";
	include_once $config['SiteClassPath']."class.car_year.php";

$options= '<option value="Airboat">Airboat</option><option value="Barge">Barge</option><option value="Catamaran">Catamaran</option><option value="Dinghy">Dinghy</option><option value="Duck%20Boat">Duck Boat</option><option value="Houseboat">Houseboat</option><option value="Hover%20Craft">Hover Craft</option><option value="Hydroplane">Hydroplane</option><option value="Inflatable">Inflatable</option><option value="Kayak">Kayak</option><option value="Paddleboat">Paddleboat</option><option value="Pontoon">Pontoon</option><option value="Pushboat">Pushboat</option><option value="Riverboat">Riverboat</option><option value="Rowboat">Rowboat</option><option value="Shuttle%20Craft">Shuttle Craft</option><option value="Ski%20Boat">Ski Boat</option><option value="Submarine">Submarine</option><option value="Tugboat">Tugboat</option>';


$res='';
$matches = array();
$data =array();

if (preg_match_all('#<option\s+value="([^"]+)">([^<]+)</option>#', $options, $matches)) 
{	
	$list = array();
	$num_matches = count($matches[0]);
 	for ($i=0 ; $i<$num_matches ; $i++) 
	{	
 		 $data= $list[$matches[1][$i]] = $matches[2][$i];
		  
		 $sql = "INSERT INTO tbl_category (Make, parent_id, boat_type , status, vin, date) VALUES ('".$data."', 2, 4, 1, 'WBADR633XXGN90545', now())";
		 $res =  mysql_query($sql) or die(mysql_error());
  	}
	
	if($res)
    {	die('Done');	}

}




?>


