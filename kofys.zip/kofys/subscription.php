<?php 
	include "includes/common.php";
	include_once $config['SiteClassPath']."class.Register.php";
	
	$ObjReg=new Register();
	
	if($_POST['login']!='')
	{
		$ObjReg->Check_MemberLog($_REQUEST);
	}
	
	if($_REQUEST['subscribe']!=''){
	if($_REQUEST['subscribe']!='' && $_REQUEST['payment']=='pending')
	{
		$ObjReg->due_payment_subscription($_SESSION['userid']);
	}else if($_REQUEST['subscribe']!='' && $_REQUEST['payment']=='renew'){
		$ObjReg->renew_payment_subscription($_SESSION['userid']);
		
	}
	}

	$ObjReg->Get_Country();
	$ObjReg->Get_Subscription();


if($_REQUEST['subscribe']!=''){
	$objSmarty->assign("amount",$_POST['subs_price']);
	$ObjReg->Profile_user($_SESSION); 
	$objSmarty->assign("IncludeTpl", "business_payment_paypal_standard.tpl");
	//$objSmarty->assign("IncludeTpl", "due_payment.tpl");
}else{
	$objSmarty->assign("IncludeTpl", "subscription.tpl");
}

$objSmarty->assign("payment_status", $_REQUEST['payment']);
$objSmarty->display("pagetemplate.tpl");

?>