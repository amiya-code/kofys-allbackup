<?php   
	
	include "includes/common.php";
	include_once $config['SiteClassPath']."class.Register.php";
	include $config['SiteClassPath']."class.split_page_results.php";
	include_once $config['SiteClassPath']."class.sell.php";
	$objSell=new sell();
	$cid=$_REQUEST['cid'];
	
	$email=$_SESSION['usermail'];
	
	$username=$_SESSION['fname'];
	
	$objSell->select_rvsmake();
	
	
	$objSell->select_rvs_review();
	
	$objSell->select_rvs_thumb();
	if($_SESSION['user_type']=='individual'){
		$status = 1;
	}else{
		$status = 1;
	}
	$status = $status*1;
	$objSmarty->assign("paymentStatus",$status); 
	
	$objSmarty->assign("email",$email);
	$objSmarty->assign("username",$username);
	$objSmarty->assign("cid",$cid);
	$objSmarty->assign("objSell",$objSell); 
	$objSmarty->assign("IncludeTpl", "rvs_review.tpl");	 
	$objSmarty->display("pagetemplate.tpl"); 
	
?>