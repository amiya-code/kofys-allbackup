<?php   
	
	include "includes/common.php";
	include_once $config['SiteClassPath']."class.sitemap.php";
	include $config['SiteClassPath']."class.split_page_results.php";
	$objsitemap = new sitemap;
	
    $objsitemap->cars_for_sale_boat_rv_motorcycles_North_Carolina_NC();
	
	$objSmarty->assign("ObjReg",$ObjReg); 
	$objSmarty->assign("IncludeTpl", "cars_for_sale_boat_rv_motorcycles_North_Carolina_NC.tpl");	 
	$objSmarty->display("pagetemplate.tpl"); 
	
?>