<?php 
	include "includes/common.php";
 

$objSmarty->assign("IncludeTpl", "logout_success.tpl");
$objSmarty->display("pagetemplate.tpl");
?>