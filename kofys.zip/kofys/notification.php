<?php 
	include "includes/common.php";

	include_once $config['SiteClassPath']."class.Register.php";
	include_once $config['SiteClassPath']."class.index.php";
	$ObjIndex=new Index();
	$mem_id=$_SESSION["userid"];
	$ObjReg=new Register();
	$ObjReg->LoginCheck();  
	$ObjReg->Login_UserDetails();
	if($_SESSION['user_type']=='business'){

	$ObjReg->business_expiredatematch($_SESSION['userid']); 
	}
	
	 $notification_id=$_REQUEST['notification_id'];
	$ObjReg->select_notification_view($notification_id);  
	$payment_status = $ObjReg->user_subscription_payment($_SESSION['userid']); 
	$payment_status = $payment_status*1;

	if($_REQUEST['action']=='delete'){
	
     $notification_id=$_REQUEST['notification_id'];
	 $ObjReg->deletenotification($notification_id); 
	 header('location:new_notification.php');
	}
	if($_REQUEST['Send'] != ''){
			$msg = $ObjIndex->send_reply2(); 
	}
//$Objsearch->Profile_View($mem_id); 
$objSmarty->assign("msg",$msg);
$objSmarty->assign("ObjReg",$ObjReg);
$objSmarty->assign("payment_status", $payment_status);
$objSmarty->assign("IncludeTpl", "notification.tpl");

$objSmarty->display("pagetemplate.tpl");

?>