<?php   
	
	include "includes/common.php";
	include_once $config['SiteClassPath']."class.Register.php";
	include $config['SiteClassPath']."class.split_page_results.php";
	include_once $config['SiteClassPath']."class.index.php";
	
	
	$ObjIndex=new Index();
	
	$ObjReg=new Register();
	
	$ObjReg->Get_Recent_mem();
	
	$ObjReg->Get_Country(); 
	
	 @set_time_limit(0);
	
	$zipcode=$_REQUEST['zipcode'];
	$rvstypes=$_REQUEST['rvstypes'];
	$rvsub_category=$_REQUEST['rvsub_category'];
	$body_style=$_REQUEST['body_Style'];
	$ryear_from=$_REQUEST['ryear_from'];
	$ryear_to= $_REQUEST['ryear_to'];
	$distance=$_REQUEST['distance']; 
	$rvsub_category=$_REQUEST['rvsub_category']; 
	$conditions = $_REQUEST['conditions'];	
	$limit = $_REQUEST['limit'];
	if($_POST['login']!='') 
	{
	$page="home";
	$ObjReg->Check_MemberLog($_REQUEST,$page);
	} 
	
	
	
	if($_REQUEST['Find_rv_x'] != '')
	{
	
	 $ObjIndex->Find_rvs();
	 
	 }
	 
	if($_REQUEST['search_x'] || $_REQUEST['sort'] != '' || $_REQUEST['price'] != '' || $_REQUEST['mileage'] != '' || $_REQUEST['ryear_from'] != ''|| $_REQUEST['limit'] != '' || $_REQUEST['ryear_to'] != ''){
	
	 $ObjIndex->search_result_rvs();
	
	}
	 
	
	
	$ObjIndex->Year();
	$ObjIndex->select_Rvs();
	
	$objSmarty->assign("limit",$limit); 
	$objSmarty->assign("conditions",$conditions); 
	$objSmarty->assign("rvsub_category",$rvsub_category); 
	$objSmarty->assign("distance",$distance); 
	$objSmarty->assign("zipcode",$zipcode); 
	$objSmarty->assign("rvstypes",$rvstypes); 
	$objSmarty->assign("rvsub_category",$rvsub_category); 
	$objSmarty->assign("body_style",$body_style); 
	$objSmarty->assign("ryear_from",$ryear_from); 
	$objSmarty->assign("ryear_to",$ryear_to); 
	$objSmarty->assign("ObjReg",$ObjReg); 
	$objSmarty->assign("ObjIndex",$ObjIndex); 
	$objSmarty->assign("IncludeTpl", "search_rvm.tpl");
	$objSmarty->display("pagetemplate.tpl"); 
	
?>