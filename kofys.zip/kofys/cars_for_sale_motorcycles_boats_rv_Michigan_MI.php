<?php   
	
	include "includes/common.php";
	include_once $config['SiteClassPath']."class.sitemap.php";
	include $config['SiteClassPath']."class.split_page_results.php";
	$objsitemap = new sitemap;
	
    $objsitemap->cars_for_sale_motorcycles_boats_rv_Michigan_MI();
	
	$objSmarty->assign("ObjReg",$ObjReg); 
	$objSmarty->assign("IncludeTpl", "cars_for_sale_motorcycles_boats_rv_Michigan_MI.tpl");	 
	$objSmarty->display("pagetemplate.tpl"); 
	
?>