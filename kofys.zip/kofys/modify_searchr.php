<?php   
	
	include "includes/common.php";
	include_once $config['SiteClassPath']."class.Register.php";
	include $config['SiteClassPath']."class.split_page_results.php";
	include_once $config['SiteClassPath']."class.index.php";	
	
	$ObjIndex=new Index();
	
	$ObjReg=new Register();
	
	$ObjReg->Get_Recent_mem();
	
	$ObjReg->Get_Country(); 
	
	$state=$_REQUEST['state'];
	$country=$_REQUEST['country'];
	$zipcode=$_REQUEST['zipcode'];
	$rvsmake=$_REQUEST['rvsmake'];
	$rvsub_category=$_REQUEST['rvsub_category'];
	$body_style=$_REQUEST['body_Style'];
	$ryear_from=$_REQUEST['ryear_from'];
	$ryear_to= $_REQUEST['ryear_to'];
	$distance=$_REQUEST['distance']; 
	$rvsub_category=$_REQUEST['rvsub_category']; 
	$conditions = $_REQUEST['conditions'];	
	if($_POST['login']!='') 
	{
	$page="home";
	$ObjReg->Check_MemberLog($_REQUEST,$page);
	}
	
	
	$ObjIndex->Year();
	$ObjIndex->rvstype();
	$objSmarty->assign("conditions",$conditions); 
	$objSmarty->assign("rvsub_category",$rvsub_category); 
	$objSmarty->assign("distance",$distance); 
	$objSmarty->assign("state",$state); 
	$objSmarty->assign("country",$country); 
	$objSmarty->assign("zipcode",$zipcode); 
	$objSmarty->assign("rvsmake",$rvsmake); 
	$objSmarty->assign("rvsub_category",$rvsub_category); 
	$objSmarty->assign("body_style",$body_style); 
	$objSmarty->assign("ryear_from",$ryear_from); 
	$objSmarty->assign("ryear_to",$ryear_to); 
	$objSmarty->assign("ObjReg",$ObjReg); 
	$objSmarty->assign("ObjIndex",$ObjIndex); 
	//$objSmarty->assign("IncludeTpl", "search_rv.tpl");
	$objSmarty->display("modify_searchr.tpl"); 
	
?>