<?php   
	
	include "includes/common.php";
	include_once $config['SiteClassPath']."class.Register.php";
	include $config['SiteClassPath']."class.split_page_results.php";
	include_once $config['SiteClassPath']."class.sell.php";
	$objSell=new sell();
	$objReg=new Register();
	
	$objReg->LoginCheck();
	
	$var=$_SERVER['REQUEST_URI'];

 	$tt=explode('/',$var);

	$expire=time()+60*60*24*30;
	setcookie("sellcars", $var, $expire);
	
	$objSell->Year();
	
	$objSell->select_edit_boat();
	
	$objSell->select_boatmake();
	
	
	if($_REQUEST['Update'])
	{
	$objSell->edit_sellboat();
	}
	
	
	
	$objSell->boattype();
	
	$objSmarty->assign("ObjReg",$ObjReg); 
	$objSmarty->assign("IncludeTpl", "edit_boatreview.tpl");	 
	$objSmarty->display("pagetemplate.tpl"); 
	
?>