<?php   error_reporting(0);
	
	include "includes/common.php";
	include_once $config['SiteClassPath']."class.Register.php";
	include $config['SiteClassPath']."class.split_page_results.php";
	include_once $config['SiteClassPath']."class.index.php";
	ini_set('memory_limit', '1024M');
	set_time_limit(0);
	
	$ObjIndex=new Index();
	
	$ObjReg=new Register();
	
	
	
	$zipcode=$_REQUEST['zipcode'];
	$city=$_REQUEST['city'];
	$boattype=$_REQUEST['boattype'];
	$bosub_category=$_REQUEST['bosub_category'];
	$byear_from=$_REQUEST['byear_from'];
	$byear_to= $_REQUEST['byear_to'];
	$distance=$_REQUEST['distance'];
	$sub_category=$_REQUEST['sub_category']; 
	$conditions = $_REQUEST['conditions'];
	$price_range = $_REQUEST['price_range'];
	$limit = $_REQUEST['limit'];
	
	if($_POST['login']!='') 
	{
		$page="home";
		$ObjReg->Check_MemberLog($_REQUEST,$page);
	} 
	
	$ObjIndex->boattype();
	
	
	if($_REQUEST['Find_boat_x'] != '' || $_REQUEST['search_x']!='')
	{
		//pr($_REQUEST);die;
		$ObjIndex->Find_boat();
		
	}
	//pr($_REQUEST);die;
	if($_REQUEST['sort']=='1')
	{
		//echo ">>>>>>>>>>>>>";
		$ObjIndex->Find_boat_sort_asc();
	}
	if($_REQUEST['sort']=='2')
	{
		//echo ">>>>>>>>>>>>>";
		$ObjIndex->Find_boat_sort_desc();
	}
	
	$ObjIndex->Year();
	
	
	if($_REQUEST['search_x'] || $_REQUEST['sort'] != '' || $_REQUEST['price'] != '' || $_REQUEST['mileage'] != '' || $_REQUEST['limit'] != '' || $_REQUEST['location'] != ''  ){
		
		//$ObjIndex->Find_boat();
		$ObjIndex->search_result_boat();
		
	}
	
	//$ObjIndex->select_countboatMake();
	
	//$ObjIndex->select_boatcategory();
	$ObjIndex->select_Boat();
	
	$objSmarty->assign("limit",$limit); 
	$objSmarty->assign("zipcode",$zipcode); 
	$objSmarty->assign("city",$city); 
	
	$milefrom=$_REQUEST['milefrom'];
	$mileto=$_REQUEST['mileto'];
	$objSmarty->assign("milefrom",$milefrom);
	$objSmarty->assign("mileto",$mileto);
	
	$objSmarty->assign("boattype",$boattype); 
	$objSmarty->assign("bosub_category",$bosub_category); 
	$objSmarty->assign("byear_from",$byear_from); 
	$objSmarty->assign("byear_to",$byear_to); 
	$objSmarty->assign("distance",$distance); 
	$objSmarty->assign("conditions",$conditions); 
	$objSmarty->assign("price_range",$price_range); 
	$objSmarty->assign("ObjReg",$ObjReg); 
	$objSmarty->assign("ObjIndex",$ObjIndex); 	
	$objSmarty->assign("IncludeTpl", "search_boat.tpl");
	$objSmarty->display("pagetemplate.tpl"); 
	
?>