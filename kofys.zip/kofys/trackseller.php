<?php   
	include "includes/common.php";
	include_once $config['SiteClassPath']."class.index.php";
	$ObjIndex=new Index();
	$userId = $_REQUEST['user'];
	$ObjIndex->seller_track($userId);
	
?>