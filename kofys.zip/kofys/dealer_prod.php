<?php   
	
	include "includes/common.php";
	//include_once $config['SiteClassPath']."class.Register.php";
	include $config['SiteClassPath']."class.split_page_results.php";
	include_once $config['SiteClassPath']."class.index.php";
	
	$ObjIndex=new Index();
	//$ObjReg=new Register();
	//$ObjReg->Get_Recent_mem();
	
	//$ObjReg->Get_Country(); 
	$smarty = new Smarty ();
	
	
	
	
    //print_r($_REQUEST); echo '<pre>';
	
	@set_time_limit(0);
	if($_POST['login']!='') 
	{
		$page="home";
		$ObjReg->Check_MemberLog($_REQUEST,$page);
	} 
	
	$zipcode=$_REQUEST['zipcode'];
	$category=$_REQUEST['category'];
	$sub_category=$_REQUEST['sub_category'];
	 $body_style=$_REQUEST['body_style']; 
	//print_r($_REQUEST); 
	//$motortype=$_REQUEST['body_style'];

	if($_REQUEST['model']){
		$model = $_REQUEST['model'];
	}else{
		$model = '';
	}
	if(!empty($_REQUEST['pricefrom'])){
	$pricefrom=$_REQUEST['pricefrom'];
	}else{
		$pricefrom=0;
	}
	if(!empty($_REQUEST['priceto'])){
	$priceto= $_REQUEST['priceto'];
	}else{
		$priceto=75000;
	}

	if(!empty($_REQUEST['year_from'])){
	$year_from=$_REQUEST['year_from'];
	}else{
		
		$year_from='1976';
	}
	if(!empty($_REQUEST['year_to'])){
	$year_to= $_REQUEST['year_to'];
	}else{
		$year_to= date('Y');
	}

	//$year_from=$_REQUEST['year_from'];
	//$year_to= $_REQUEST['year_to'];

	$distance=$_REQUEST['distance']; 
	$sub_category=$_REQUEST['sub_category']; 
	$conditions = $_REQUEST['conditions'];
	$price_range = $_REQUEST['price_range'];
	$limit = $_REQUEST['limit'];
	$sub_sub_parent_id = $_REQUEST['sub_sub_parent_id'];

	$id=$_REQUEST['id'];
	// new code by Trinkal juneja for view more products from this dealer on 31-05-2011	
	$limit=$_GET['limit'];
	$mem_id=$_GET['id'];
	
	
	if($_REQUEST['id']){
	
	 $ObjIndex->more_prod();
	 $ObjIndex->get_dealername();
	
	}
	
	
	
	
	
	$objSmarty->assign("data",$data);		//for category table
	$objSmarty->assign("data1",$data1);		//for member table
	$objSmarty->assign("model",$model); 
	$objSmarty->assign("limit",$limit); 
	$objSmarty->assign("sub_sub_parent_id",$sub_sub_parent_id); 
	$objSmarty->assign("conditions",$conditions); 
	$objSmarty->assign("sub_category",$sub_category); 
	$objSmarty->assign("distance",$distance); 
	$objSmarty->assign("zipcode",$zipcode); 
	$objSmarty->assign("category",$category); 
	$objSmarty->assign("sub_category",$sub_category); 
	$objSmarty->assign("body_style",$body_style);
	$objSmarty->assign("motortype",$motortype); 
	$objSmarty->assign("year_from",$year_from); 
	$objSmarty->assign("year_to",$year_to); 
	$objSmarty->assign("pricefrom",$pricefrom); 
	$objSmarty->assign("priceto",$priceto); 
	$objSmarty->assign("price_range",$price_range); 	
	$objSmarty->assign("ObjReg",$ObjReg); 
	$objSmarty->assign("ObjIndex",$ObjIndex);
	$objSmarty->assign("id",$id); 
	$objSmarty->assign("IncludeTpl", "dealer_prod.tpl");
	$objSmarty->display("pagetemplate.tpl"); 
	
	
	
	



?>