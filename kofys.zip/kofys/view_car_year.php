<?php 

	include "includes/common.php";
	include_once $config['SiteClassPath']."class.car_year.php";
	include $config['SiteClassPath']."class.split_page_results.php";
	//include_once $config['SiteClassPath']."class.Admin.php";
	
	//$objAdmin		= new Admin();
	//$objStore	= new store();
	$objcaryear = new caryear();
	
	
	
	///$objAdmin->chkLogin();
	 
	$pid=$_REQUEST['pid']; 
	
	
	
	
	if($_REQUEST['pid']!=='')
	{
	$objcaryear->select_car_year();
	}
	
	$objSmarty->assign("pid",$pid);
	$objSmarty->assign("IncludeTpl", "view_car_year.tpl");
	$objSmarty->display("pagetemplate.tpl");
		
?>
