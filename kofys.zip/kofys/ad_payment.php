<?php   
	
	include "includes/common.php";
	include_once $config['SiteClassPath']."class.Register.php";
	include $config['SiteClassPath']."class.split_page_results.php";
	include_once $config['SiteClassPath']."class.myads.php";
	
	
	$Objmyads=new myads();
	
	$ObjReg=new Register();

	if($_REQUEST['uid']!='')
	{
	$DelQry="Delete from tbl_category where category_id='".$_REQUEST['uid']."'";
	$Objmyads->ExecuteQuery($DelQry,"delete");
	}
	
	if($_SESSION['userid']!=='')
	{
	$Objmyads->select_payment_ads();	
	}
	
	


	 
	$objSmarty->assign("ObjReg",$ObjReg); 
	$objSmarty->assign("IncludeTpl", "ad_payment.tpl");
	$objSmarty->display("pagetemplate.tpl"); 
	
?>