<?php   
	
	include "includes/common.php";
	include_once $config['SiteClassPath']."class.sitemap.php";
	include $config['SiteClassPath']."class.split_page_results.php";
	$objsitemap = new sitemap;
	
    $objsitemap->voiture_occasion_paris();
	
	$objSmarty->assign("ObjReg",$ObjReg); 
	$objSmarty->assign("IncludeTpl", "voiture_occasion_paris.tpl");	 
	$objSmarty->display("pagetemplate.tpl"); 
	
?>