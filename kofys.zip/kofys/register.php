<?php 
	include "includes/common.php";
	include_once $config['SiteClassPath']."class.Register.php";
	
	$ObjReg=new Register();
	
	if($_SESSION['userid']!='')
	{
	 header("location:profile.php");
	 }
	
	
	if($_POST['login']!='')
	{
		$ObjReg->Check_MemberLog($_REQUEST);
	}
	
	
		
	$ObjReg->Get_Country();
	$ObjReg->Get_Subscription();
	
	
	if($_REQUEST['type'] == 'business') 
	{
	    $baseUrl = WWW_BASE;
        

		
		if($_REQUEST['regist'] != '') {
	
		$ObjReg->Newmember_Register(); 

		}
	
	
		$objSmarty->assign("ObjReg",$ObjReg);
		$objSmarty->assign("baseUrl",$baseUrl);
		$objSmarty->assign("IncludeTpl", "business.tpl");
	   
	}else
	{
	   
		if($_REQUEST['regist'] != '') {
		
		
	
		$ObjReg->Newmember_Register(); 
		
		}
		
		$objSmarty->assign("ObjReg",$ObjReg);
		$objSmarty->assign("IncludeTpl", "individual.tpl");
	}
	

$objSmarty->display("pagetemplate.tpl");
?>