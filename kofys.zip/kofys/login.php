<?php 
	include "includes/common.php";
	include_once $config['SiteClassPath']."class.Register.php";
	
	$ObjReg=new Register();
	
	if($_SESSION['userid']!='')
	{
	 header("location:profile.php");
	 }
	
	
	if($_POST['login']!='')
	{
		$ObjReg->Check_MemberLog($_REQUEST);
	}
	
	if($_POST['regist']!='')
	{
	   $ObjReg->Newmember_Register();  
	}
	
	if($_REQUEST['activation']=='Active')
	{	
		
		$SelQu = "select  * from tbl_member where id='".$_REQUEST['maxid']."'";
		$SelF=$ObjReg->ExecuteQuery($SelQu, "select");
		$total=count($SelF);
		if($total!=0)
		{
	    $SelQuery = "select  * from tbl_member where id='".$_REQUEST['maxid']."' and status = 1";
		$SelFrid=$ObjReg->ExecuteQuery($SelQuery, "select");
		
	     $Total=count($SelFrid);
		 
		 if($Total==0) {
	
	 			$query = "update tbl_member set status=1 where id ='".$_REQUEST['maxid']."'";
	 			$result =$ObjReg->ExecuteQuery($query,"update");
	 
			
					$objSmarty->assign("msg","Conratulations! Your account has been activated. Please login.");
				 
		  }
		  else
		  {
		    $objSmarty->assign("msg","Already Activated");
		  }
		   }
		  else
		  {
		    $objSmarty->assign("msg","User not Exist");
		  }
	}
	
$ObjReg->Get_Country();
$objSmarty->assign("ObjReg",$ObjReg);
$objSmarty->assign("IncludeTpl", "login.tpl");
$objSmarty->display("pagetemplate.tpl");
?>