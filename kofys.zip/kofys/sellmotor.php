<?php   
	
	include "includes/common.php";
	include_once $config['SiteClassPath']."class.Register.php";
	include $config['SiteClassPath']."class.split_page_results.php";
	include_once $config['SiteClassPath']."class.sell.php";
	$objReg=new Register();
	$objSell=new sell();
	
	$objReg->LoginCheck();
	
	$var=$_SERVER['REQUEST_URI'];

 	$tt=explode('/',$var);

	$expire=time()+60*60*24*30;
	
	setcookie("sellmotor", $var, $expire);
	
	$objSell->Year();

	/***if business user is not allowed to add any vechile***/
	 $payment_status = $objReg->Get_businesspayment($_SESSION['userid']);
	if(!empty($payment_status)){
		$status = 0;
	}else{
		$status = 1;
	}
	$status = $status*1;
	if($status=='0'){
		header("Location:profile.php"); 
	}
	

	/***if business user is not allowed to add any vechile***/
	
	$objSell->select_motormake();
	
	if($_REQUEST['Add'])
	{
	
	$objSell->add_sellmotor();
	    
	
	}

	
	$objSmarty->assign("ObjReg",$ObjReg); 
	$objSmarty->assign("IncludeTpl", "sellmotor.tpl");	 
	$objSmarty->display("pagetemplate.tpl"); 
	
?>