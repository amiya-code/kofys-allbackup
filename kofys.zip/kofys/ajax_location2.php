<?php
include "includes/common.php";
include_once $config['SiteClassPath']."class.SqlFunctions.php";
$objMysql = new MysqlFns(); 
extract($_REQUEST);
$SelQuery = "select * from tbl_category where sub_parent_id='$category_id' group by model asc ";
$GetState	= $objMysql->ExecuteQuery($SelQuery, "select");

echo '<select id="sub_category" name="sub_category" style="width:108px;" class="username">
<option value="">Select Model</option>';
foreach($GetState as $val)
{
		/*if(($val['Ident']==$_REQUEST['sid']) ||($val['Ident']==$sid) || ($val['Ident']==$_REQUEST['stateid']))
		{
		$sel="selected";
		}else{$sel="";}*/
	echo "<option value=\"$val[category_id]\" >$val[model]</option>";
}  echo "</select>";

?>



<?php 
/*	include "includes/common.php";
	$sql= new MysqlFns();
	
	extract($_REQUEST);
echo $result1="select * from tbl_category where sub_parent_id='$category_id' group by model asc ";
$exe=$sql->ExecuteQuery($result1,"select");
echo '<select id="sub_category" name="sub_category" style="width:108px;" onchange="vali1();">
<option value="">Select Model</option>';
foreach($exe as $val){
echo "<option value=\"$val[model]\" >$val[model]</option>";
}
echo "</select>";*/

?>