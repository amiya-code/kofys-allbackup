<?php   
	
	include "includes/common.php";
	include_once $config['SiteClassPath']."class.Register.php";
	include $config['SiteClassPath']."class.split_page_results.php";
	include_once $config['SiteClassPath']."class.index.php";

	$ObjIndex=new Index();
	$ObjReg=new Register();
	$ObjReg->Get_Recent_mem();	
	$ObjReg->Get_Country(); 
	
	$zipcode=$_REQUEST['zipcode'];
	$motor=$_REQUEST['motor'];
	$mosub_category=$_REQUEST['mosub_category'];
	$body_style=$_REQUEST['body_Style'];
	$myear_from=$_REQUEST['myear_from'];
	$myear_to= $_REQUEST['myear_to'];
	$distance=$_REQUEST['distance']; 
	$mosub_category=$_REQUEST['mosub_category']; 
	$conditions = $_REQUEST['conditions'];
	
	if($_POST['login']!='') 
	{
	$page="home";
	$ObjReg->Check_MemberLog($_REQUEST,$page);
	} 

	/*if($_REQUEST['sort']=='1')
	{
	//echo ">>>>>>>>>>>>>";
	$ObjIndex->Find_motor_sort_asc();
	}
	if($_REQUEST['sort']=='2')
	{
	//echo ">>>>>>>>>>>>>";
	$ObjIndex->Find_motor_sort_desc();
	}*/
	

	$ObjIndex->Year();
	$ObjIndex->select_Motor123();
	
	if($_REQUEST['search_x']){
	
	 $ObjIndex->search_result_motor();
	
	}
	
	
	$objSmarty->assign("conditions",$conditions); 
	$objSmarty->assign("mosub_category",$mosub_category); 
	$objSmarty->assign("distance",$distance); 
	$objSmarty->assign("zipcode",$zipcode); 
	$objSmarty->assign("motor",$motor); 
	$objSmarty->assign("mosub_category",$mosub_category); 
	$objSmarty->assign("body_style",$body_style); 
	$objSmarty->assign("myear_from",$myear_from); 
	$objSmarty->assign("myear_to",$myear_to); 
	$objSmarty->assign("ObjIndex",$ObjIndex);
	$objSmarty->assign("ObjReg",$ObjReg); 
	//$objSmarty->assign("IncludeTpl", "search_motor.tpl");
	$objSmarty->display("modify_searchm.tpl"); 
	
?>