<?php   
	
	include "includes/common.php";
	include_once $config['SiteClassPath']."class.sitemap.php";
	include $config['SiteClassPath']."class.split_page_results.php";
	$objsitemap = new sitemap;
	
    $objsitemap->araba_satış_motosiklet_bayileri_Türkiye_Tr();
	
	$objSmarty->assign("ObjReg",$ObjReg); 
	$objSmarty->assign("IncludeTpl", "araba_satış_motosiklet_bayileri_Türkiye_Tr.tpl");	 
	$objSmarty->display("pagetemplate.tpl"); 
	
?>