<?php   
	
	include "includes/common.php";
	include_once $config['SiteClassPath']."class.sitemap.php";
	include $config['SiteClassPath']."class.split_page_results.php";
	$objsitemap = new sitemap;
	
    $objsitemap->cars_sale_motorcycle_boat_rv_ohio();
	
	$objSmarty->assign("ObjReg",$ObjReg); 
	$objSmarty->assign("IncludeTpl", "cars_sale_motorcycle_boat_rv_ohio.tpl");	 
	$objSmarty->display("pagetemplate.tpl"); 
	
?>