<?php   
	
	include "includes/common.php";
	include_once $config['SiteClassPath']."class.Register.php";
	include $config['SiteClassPath']."class.split_page_results.php";
	include_once $config['SiteClassPath']."class.myads.php";
	//$objSell=new sell();
	
	$Objmyads=new myads();
	
	$cid=$_REQUEST['cid'];
	
	$email=$_SESSION['usermail'];
	
	$username=$_SESSION['fname'];
	
	$Objmyads->view_details();
	
	$Objmyads->select_car_thumb();
	
	$objSmarty->assign("email",$email);
	$objSmarty->assign("username",$username);
	$objSmarty->assign("cid",$cid);
	$objSmarty->assign("Objmyads",$Objmyads);
	$objSmarty->assign("IncludeTpl", "myads_car_review.tpl");	 
	$objSmarty->display("pagetemplate.tpl"); 
	
?>