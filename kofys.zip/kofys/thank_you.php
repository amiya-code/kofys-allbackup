<?php 
	include "includes/common.php";
	include_once $config['SiteClassPath']."class.Register.php";
	//pr('abcd');die;
	$ObjReg=new Register();
 
$objSmarty->assign("IncludeTpl", "thank_you.tpl");
$objSmarty->display("pagetemplate.tpl");
?>