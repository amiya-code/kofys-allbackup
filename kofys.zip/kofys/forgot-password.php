<?php 
	include "includes/common.php";
	include_once $config['SiteClassPath']."class.Register.php";
	$ObjReg=new Register();
	
	if($_POST['submit']!='')
	{
	   $ObjReg->Send_Password(); 
	}
	
	if($_POST['cancelfor']!='')
	{
	  header("location:index.php");
	}
	
	
	$ObjReg->Get_Country();
	
$objSmarty->assign("ObjReg",$ObjReg);
$objSmarty->assign("IncludeTpl", "forgot.tpl");
$objSmarty->display("pagetemplate.tpl");
?>