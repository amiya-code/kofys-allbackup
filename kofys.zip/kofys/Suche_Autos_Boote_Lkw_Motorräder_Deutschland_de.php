<?php   
	
	include "includes/common.php";
	include_once $config['SiteClassPath']."class.sitemap.php";
	include $config['SiteClassPath']."class.split_page_results.php";
	$objsitemap = new sitemap;
	
    $objsitemap->Suche_Autos_Boote_Lkw_Motorräder_Deutschland_de();
	
	$objSmarty->assign("ObjReg",$ObjReg); 
	$objSmarty->assign("IncludeTpl", "Suche_Autos_Boote_Lkw_Motorräder_Deutschland_de.tpl");	 
	$objSmarty->display("pagetemplate.tpl"); 
	
?>