<html> 
<head> 
<title>Document</title> 
</head> 
<?php 
if( $_POST['Submit']){ 
    $distance = distance($_POST[LAT1], $_POST[LONG1], $_POST[LAT2],$_POST[LONG2]); 
     
} 


function distance($Aa, $Ba, $Ca, $Da){ 
// this is just some basic error checking i'd normally put it into a seperate file but 
// for the purposes of this file... well you know. 
    $input = array($Aa, $Ba, $Ca, $Da); 
    foreach($input as $name){ 
        if (ereg("[[:alpha:]]",$name)){ 
            echo "You cannot enter letters into this function<br>\n"; 
            die; 
        } 
        if(ereg("\.",$name)){ 
            $dot = "."; 
            $pos = strpos($name, $dot); 
            //echo $pos." <br>\n"; 
            if($pos > 3){ 
                echo "The input cannot exceed more than 3 digits left of the decimal<br>\n"; 
                die; 
            } 
        } 
        if($name > 365){ 
            echo "The input cannot exceed 365 degrees <BR>\n"; 
            die; 
         
        } 
    } 
     
     
     
    $A = $Aa/57.29577951; 
    $B = $Ba/57.29577951; 
      $C = $Ca/57.29577951; 
    $D = $Da/57.29577951; 
    //convert all to radians: degree/57.29577951 
     
   if ($A == $C && $B == $D ){ 
     $dist = 0; 
   } 
   else if ( (sin($A)* sin($C)+ cos($A)* cos($C)* cos($B-$D)) > 1){ 
   $dist = 3963.1* acos(1);// solved a prob I ran into.  I haven't fully analyzed it yet    
    
   } 
                     
   else{ 

           $dist = 3963.1* acos(sin($A)*sin($C)+ cos($A)* cos($C)* cos($B-$D)); 
    } 
return ($dist); 
} 


?> 
<body bgcolor="#FFFFFF" text="#000000"> 
<form name="form1" method="post" action=""> 
  <p>Point one Lat 
    <input type="text" name="LAT1" value="<?php $_POST[LAT1]?>" > 
    Long 
    <input type="text" name="LONG1" value="<?php $_POST[LONG1] ?>"> 
  </p> 
  <p>Point two Lat 
    <input type="text" name="LAT2" value="<?php $_POST[LAT2]?>"> 
    Long 
    <input type="text" name="LONG2" value="<?php $_POST[LONG2]?>"> 
  </p> 
  <p> 
    <input type="submit" name="Submit" value="Submit"> 
  </p> 
</form> 
<?php echo "<br>distance = ".$distance." miles (as the crow flies)<br>"; ?> 
</body> 
</html>
