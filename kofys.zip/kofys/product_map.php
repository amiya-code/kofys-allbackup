<?php

	include "includes/common.php";
	include_once $config['SiteClassPath']."class.Register.php";
	include $config['SiteClassPath']."class.split_page_results.php";
	include_once $config['SiteClassPath']."class.index.php";	
	$ObjIndex=new Index();
	$ObjReg=new Register();
	$ObjReg->Get_Recent_mem(); 
	$ObjReg->Get_Country(); 
    //print_r($_REQUEST); echo '<pre>';
	if($_POST['login']!='') 
	{
		$page="home";
		$ObjReg->Check_MemberLog($_REQUEST,$page);
	} 
	$zipcode=$_REQUEST['zipcode'];
	$category=$_REQUEST['category'];
	$sub_category=$_REQUEST['sub_category'];
	$body_style=$_REQUEST['body_Style'];
	$year_from=$_REQUEST['year_from'];
	$year_to= $_REQUEST['year_to'];
	$distance=$_REQUEST['distance']; 
	$sub_category=$_REQUEST['sub_category']; 
	$conditions = $_REQUEST['conditions'];
	if($_REQUEST['Find_auto_x'])
	{
		$ObjIndex->Find_auto();
	}
	if($_REQUEST['product_id'] != ''){
		$ObjIndex->product_details();
	}
	if($_REQUEST['Send'] != ''){
		if(empty($_POST['fname'])){
			$captcha_error1  = "\n Please enter first name."; 
			$cap1 = "invalid1";
			$cfname = $_POST['fname'];
			$clname = $_POST['lname'];;
			$cemail = $_POST['email'];
			$cphone = $_POST['phone'];
			$czip = $_POST['zipcode'];
			$cmsg = $_POST['msg'];
		}else if(empty($_POST['lname'])){
			$captcha_error1  = "\n Please enter last name."; 
			$cap1 = "invalid1";
			$cfname = $_POST['fname'];
			$clname = $_POST['lname'];;
			$cemail = $_POST['email'];
			$cphone = $_POST['phone'];
			$czip = $_POST['zipcode'];
			$cmsg = $_POST['msg'];
		}else if(empty($_POST['email'])){
			$captcha_error1  = "\n Please enter email id."; 
			$cap1 = "invalid1";
			$cfname = $_POST['fname'];
			$clname = $_POST['lname'];;
			$cemail = $_POST['email'];
			$cphone = $_POST['phone'];
			$czip = $_POST['zipcode'];
			$cmsg = $_POST['msg'];
		}else if(!preg_match("/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,})$/i", $_POST['email'])){
			$captcha_error1  = "\n Please enter valid email id."; 
			$cap1 = "invalid1";
			$cfname = $_POST['fname'];
			$clname = $_POST['lname'];;
			$cemail = $_POST['email'];
			$cphone = $_POST['phone'];
			$czip = $_POST['zipcode'];
			$cmsg = $_POST['msg'];
		}else if(empty($_POST['phone'])){
			$captcha_error1  = "\n Please enter phone."; 
			$cap1 = "invalid1";
			$cfname = $_POST['fname'];
			$clname = $_POST['lname'];;
			$cemail = $_POST['email'];
			$cphone = $_POST['phone'];
			$czip = $_POST['zipcode'];
			$cmsg = $_POST['msg'];
		}else if(empty($_POST['zipcode'])){
			$captcha_error1  = "\n Please enter zipcode."; 
			$cap1 = "invalid1";
			$cfname = $_POST['fname'];
			$clname = $_POST['lname'];;
			$cemail = $_POST['email'];
			$cphone = $_POST['phone'];
			$czip = $_POST['zipcode'];
			$cmsg = $_POST['msg'];
		}else if(empty($_SESSION['6_letters_code'] ) || strcmp($_SESSION['6_letters_code'], $_POST['6_letters_code']) != 0)
		{
			//Note: the captcha code is compared case insensitively.
			//if you want case sensitive match, update the check above to
			// strcmp()
			//alert('gdfhsf');
			$captcha_error1  = "\n The verification code does not match!"; 
			$cap1 = "invalid1";
			$cfname = $_POST['fname'];
			$clname = $_POST['lname'];;
			$cemail = $_POST['email'];
			$cphone = $_POST['phone'];
			$czip = $_POST['zipcode'];
			$cmsg = $_POST['msg'];
		}else{
			$ObjIndex->send_mail();
		}
	}
	if($_REQUEST['zip_code'] != '')
	{
		extract($_REQUEST);
		$zip3=mysql_query("select * from ziplanglong where zipcode = '".$_REQUEST['zip_code']."'");
		//$objSmarty->assign("sear_result",$zip3);
		while($res1=mysql_fetch_array($zip3))
		{
			$lat2=$res1['lang'];
			$lon2=$res1['lon'];
			$objSmarty->assign("lon",$lon2); 
			$objSmarty->assign("lat",$lat2); 
		}
	}
	$ObjIndex->Year();
	$ObjIndex->select_Category();
	$ObjIndex->select_Boat();
	$ObjIndex->select_Motor();
	$ObjIndex->select_Rvs();
	$ObjIndex->rvstype();
	//$objcaryear->select_caryear();
	$objSmarty->assign("cfname",$cfname); 
	$objSmarty->assign("clname",$clname); 
	$objSmarty->assign("cemail",$cemail); 
	$objSmarty->assign("cphone",$cphone); 
	$objSmarty->assign("czip",$czip); 
	$objSmarty->assign("cmsg",$cmsg);
	$objSmarty->assign("captcha_error1",$captcha_error1); 
	$objSmarty->assign("cap1",$cap1); 
	$objSmarty->assign("conditions",$conditions); 
	$objSmarty->assign("sub_category",$sub_category); 
	$objSmarty->assign("distance",$distance); 
	$objSmarty->assign("zipcode",$zipcode); 
	$objSmarty->assign("category",$category); 
	$objSmarty->assign("sub_category",$sub_category); 
	$objSmarty->assign("body_style",$body_style); 
	$objSmarty->assign("year_from",$year_from); 
	$objSmarty->assign("year_to",$year_to); 
	$objSmarty->assign("ObjReg",$ObjReg); 
	$objSmarty->assign("ObjIndex",$ObjIndex);
	$objSmarty->assign("IncludeTpl", "product_map.tpl");
	$objSmarty->display("pagetemplate.tpl"); 
?>