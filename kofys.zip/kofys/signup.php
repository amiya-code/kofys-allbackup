<?php 
	include "includes/common.php";
	include_once $config['SiteClassPath']."class.Register.php";
	
	$ObjReg=new Register();
	
	if($_SESSION['userid']!='')
	{
	 header("location:profile.php");
	 }
	
	
	if($_POST['login']!='')
	{
		$ObjReg->Check_MemberLog($_REQUEST);
	}
	
	
	 
	 
	
	
	if($_POST['usertype']!='')
	{
	
	
	    
	  // $ObjReg->Newmember_Register();  
	  
	// session_register("fname");
			$_SESSION["Payment_Amount"]='5';
			
		$_SESSION["Payment_Amount"];
	  
	   $usertype = $_REQUEST['usertype'];
	  
	  if($_REQUEST['usertype'] == 'business')
	  {
	     header("location:register.php?type=$usertype"); 
	     
	  }else{
	  
	  	 header("location:register.php?type=$usertype"); 
	  }
	  
	  
	}
	
	
	
	$ObjReg->Get_Country();
	
$objSmarty->assign("ObjReg",$ObjReg);
$objSmarty->assign("IncludeTpl", "signup.tpl");
$objSmarty->display("pagetemplate.tpl");
?>