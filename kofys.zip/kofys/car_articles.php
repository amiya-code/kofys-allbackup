<?php   
	
	include "includes/common.php";
	include_once $config['SiteClassPath']."class.Content.php";
	include $config['SiteClassPath']."class.split_page_results.php";
	$objcon=new Content();
	
	$objcon->select_articles();
	
	//$objSmarty->assign("ObjReg",$ObjReg); 
	$objSmarty->assign("IncludeTpl", "car_articles.tpl");	 
	$objSmarty->display("pagetemplate.tpl"); 
	
?>