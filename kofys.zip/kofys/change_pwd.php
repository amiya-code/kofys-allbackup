<?php 
	include "includes/common.php";

	include_once $config['SiteClassPath']."class.Register.php";
	include_once $config['SiteClassPath']."class.index.php";
	
	
	$ObjIndex=new Index();

	
   	
	
	$mem_id=$_SESSION["userid"];
	
	$ObjReg=new Register();

	
	$ObjReg->LoginCheck();  

	$ObjReg->Login_UserDetails(); 
	
	
	$ObjReg->Profile_user($_SESSION); 
	
	
	if($_REQUEST['Save'])
	{
	  
	 
	  
	 $ObjIndex->changePassword($_POST);
	 }
	

    //$Objsearch->Profile_View($mem_id); 

$objSmarty->assign("ObjReg",$ObjReg);

$objSmarty->assign("IncludeTpl", "change_pwd.tpl");

$objSmarty->display("pagetemplate.tpl");

?>