<?php
session_start();
echo $_SESSION['6_letters_code'];
die;
?>


