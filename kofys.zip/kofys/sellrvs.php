<?php   
	
	include "includes/common.php";
	include_once $config['SiteClassPath']."class.Register.php";
	include $config['SiteClassPath']."class.split_page_results.php";
	include_once $config['SiteClassPath']."class.sell.php";
	$objSell=new sell();
	$objReg=new Register();
	
	$objReg->LoginCheck();
	
	$var=$_SERVER['REQUEST_URI'];

 	$tt=explode('/',$var);

	$expire=time()+60*60*24*30;
	setcookie("sellrvs", $var, $expire);
	
	$objSell->Year();
	
	/***if business user is not allowed to add any vechile***/
	 $payment_status = $objReg->Get_businesspayment($_SESSION['userid']);
	if(!empty($payment_status)){
		$status = 0;
	}else{
		$status = 1;
	}
	$status = $status*1;
	if($status=='0'){
		header("Location:profile.php"); 
	}
	

	/***if business user is not allowed to add any vechile***/
	
	if($_REQUEST['Add'])
	{
	
	$objSell->add_sellrvs();
	     
	
	}
	
	
	$objSell->rvstype();
	
	//$objSell->select_Rvs123();
	
	$heavy="select * from tbl_category where parent_id = '4' order by Make desc ";
	$result4=$objSell->ExecuteQuery($heavy,"select");
	$objSmarty->assign("result4",$result4);
	
	
	
	$objSmarty->assign("ObjReg",$ObjReg); 
	$objSmarty->assign("IncludeTpl", "sellrvs.tpl");	 
	$objSmarty->display("pagetemplate.tpl"); 
	
?>