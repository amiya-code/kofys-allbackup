<?php   
	
	include "includes/common.php";
	include_once $config['SiteClassPath']."class.sitemap.php";
	include $config['SiteClassPath']."class.split_page_results.php";
	$objsitemap = new sitemap;
	
	$objsitemap->cheap_motorcycles_for_sale_in_florida();
	
	$objSmarty->assign("ObjReg",$ObjReg); 
	$objSmarty->assign("IncludeTpl", "cheap_motorcycles_for_sale_in_florida.tpl");	 
	$objSmarty->display("pagetemplate.tpl"); 
	
?>