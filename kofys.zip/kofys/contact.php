<?php   
	
	include "includes/common.php";
	include_once $config['SiteClassPath']."class.Register.php";
	include $config['SiteClassPath']."class.split_page_results.php";

	$ObjReg=new Register();
	
	$ObjReg->Get_Recent_mem();
	
	$ObjReg->Get_Country();
	
	if($_SESSION['userid']!='')
	{
	 header("location:profile.php");
	 }
	
	if($_POST['login']!='') 
	{
	$page="home";
	$ObjReg->Check_MemberLog($_REQUEST,$page);
	} 
	
	if($_POST['regist_x']!='')
	{
	$ObjReg->Newmember_Register(); 
	}

	
	
	
	
	$objSmarty->assign("ObjReg",$ObjReg); 
	$objSmarty->assign("IncludeTpl", "index.tpl");	 
	$objSmarty->display("pagetemplate.tpl"); 
	
?>