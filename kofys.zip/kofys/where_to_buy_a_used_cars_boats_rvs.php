<?php   
	
	include "includes/common.php";
	include_once $config['SiteClassPath']."class.sitemap.php";
	include $config['SiteClassPath']."class.split_page_results.php";
	$objsitemap = new sitemap;
	
	$objsitemap->where_to_buy_a_used_cars_boats_rvs();
	
	$objSmarty->assign("ObjReg",$ObjReg); 
	$objSmarty->assign("IncludeTpl", "where_to_buy_a_used_cars_boats_rvs.tpl");	 
	$objSmarty->display("pagetemplate.tpl"); 
	
?>