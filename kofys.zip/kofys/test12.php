













    
    
    



<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
    "https://www.w3.org/TR/html4/loose.dtd">













<html>
    <head>
        <meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
        <meta http-equiv="Cache-Control" content="no-cache,no-store,private,must-revalidate,max-stale=0,post-check=0,pre-check=0">
        <meta http-equiv="Pragma" content="no-cache">
        <meta http-equiv="Expires" content="-1">
        <meta http-equiv="Expires" content="Sat, 01 Jan 1980 00:00:00 GMT">
        
        <title>AusBBS | Welcome To Our Customer Portal</title>
        <link rel="shortcut icon" href="https://customerportal.utilibill.com.au/ausbbs/images/ausbbs/favicon.ico" type="image/x-icon" />
        <link href="https://customerportal.utilibill.com.au/ausbbs/css/ausbbs.css" type="text/css" media="screen" rel="stylesheet" />
        <link rel="stylesheet" href="https://customerportal.utilibill.com.au/ausbbs/themes/ausbbs/jquery.ui.all.css"/>

        <!--STYLESHEET DECLARATIONS-->
        <link rel="stylesheet" href="https://customerportal.utilibill.com.au/ausbbs/themes/jquery.ui.selectmenu.css">
        <link href="https://customerportal.utilibill.com.au/ausbbs/slider/css/anythingslider.css" type="text/css" media="screen" rel="stylesheet" />
        <link rel="stylesheet" href="https://customerportal.utilibill.com.au/ausbbs/select/jquery.sb.css" type="text/css" media="all" />
        <link rel="stylesheet" type="text/css" href="https://customerportal.utilibill.com.au/ausbbs/table/css/base.css" />
        <link rel="stylesheet" href="https://customerportal.utilibill.com.au/ausbbs/fancybox/jquery.fancybox-1.3.4.css" type="text/css" media="screen" />
        <link rel="stylesheet" href="https://customerportal.utilibill.com.au/ausbbs/showLoading/css/showLoading.css" type="text/css" media="screen" />
        <link href="https://customerportal.utilibill.com.au/ausbbs/bubble/jquery.bubblepopup.v2.3.1.css" rel="stylesheet" type="text/css" />

        <!--JAVASCRIPT DECLARATIONS-->
        <script type="text/javascript" src="javascript/sorttable.js"></script>
        <script type="text/javascript" src="jquery-1.6.2.js"></script>
        <script type="text/javascript" src="jquery-ui-1.8.16.custom.min.js"></script>
        <script type="text/javascript" src="slider/js/jquery.anythingslider.js"></script>
        <script type="text/javascript" src="slider/js/jquery.easing.1.2.js"></script>
        <script type="text/javascript" src="ui/jquery.ui.core.js"></script>

        <script type="text/javascript" src="ui/jquery.ui.widget.js"></script>
        <script type="text/javascript" src="ui/jquery.ui.button.js"></script>
        <script type="text/javascript" src="ui/jquery.ui.tabs.js"></script>
        <script type="text/javascript" src="ui/jquery.ui.mouse.js"></script>
        <script type="text/javascript" src="ui/jquery.ui.draggable.js"></script>
        <script type="text/javascript" src="ui/jquery.ui.position.js"></script>
        <script type="text/javascript" src="ui/jquery.ui.resizable.js"></script>
        <script type="text/javascript" src="ui/jquery.ui.dialog.js"></script>
        <script type="text/javascript" src="ui/jquery.ui.datepicker.js"></script>

        <script type="text/javascript" src="ui/jquery.effects.core.js"></script>
        <script type="text/javascript" src="ui/jquery.effects.blind.js"></script>

        <script type="text/javascript" src="ui/jquery.effects.bounce.js"></script>
        <script type="text/javascript" src="ui/jquery.effects.clip.js"></script>
        <script type="text/javascript" src="ui/jquery.effects.drop.js"></script>
        <script type="text/javascript" src="ui/jquery.effects.explode.js"></script>
        <script type="text/javascript" src="ui/jquery.effects.fold.js"></script>
        <script type="text/javascript" src="ui/jquery.effects.highlight.js"></script>

        <script type="text/javascript" src="ui/jquery.effects.pulsate.js"></script>
        <script type="text/javascript" src="ui/jquery.effects.scale.js"></script>
        <script type="text/javascript" src="ui/jquery.effects.shake.js"></script>
        <script type="text/javascript" src="ui/jquery.effects.slide.js"></script>
        <script type="text/javascript" src="ui/jquery.cookie.js"></script>

        <script type="text/javascript" src="ui/jquery.pagination.js"></script>
        <script type="text/javascript" src="bubble/jquery.bubblepopup.v2.3.1.min.js"></script>

        <script type="text/javascript" src="select/lib/jquerytie/jquery.tie.js"></script>
        <script type="text/javascript" src="select/jquery.sb.js"></script>

        <script type="text/javascript" src="table/highlighter/codehighlighter.js"></script>
        <script type="text/javascript" src="table/highlighter/javascript.js"></script>
        <script type="text/javascript" src="table/javascript/jquery.fixheadertable.js"></script>
        <script type="text/javascript" src="table/javascript/jquery.fixheadertable.min.js"></script>

        <script type="text/javascript" src="fancybox/jquery.fancybox-1.3.4.pack.js"></script>
        <script type="text/javascript" src="https://customerportal.utilibill.com.au/ausbbs/fancybox/jquery.easing-1.3.pack.js"></script>
        <script type="text/javascript" src="https://customerportal.utilibill.com.au/ausbbs/fancybox/jquery.mousewheel-3.0.4.pack.js"></script>

        <script type="text/javascript" src="https://customerportal.utilibill.com.au/ausbbs/showLoading/js/jquery.showLoading.js"></script>

        <!--[if IE]><script language="javascript" type="text/javascript" src="flot/excanvas.min.js"></script><![endif]-->
        <script language="javascript" type="text/javascript" src="https://customerportal.utilibill.com.au/ausbbs/flot/jquery.flot.js"></script>
        <script language="javascript" type="text/javascript" src="https://customerportal.utilibill.com.au/ausbbs/flot/jquery.flot.selection.js"></script>
        <script language="javascript" type="text/javascript" src="https://customerportal.utilibill.com.au/ausbbs/flot/jquery.flot.crosshair.js"></script>

        <script type="text/javascript" src="https://customerportal.utilibill.com.au/ausbbs/javascript/jquery.dateFormat-1.0.js"></script>
        <script type="text/javascript" src="https://customerportal.utilibill.com.au/ausbbs/javascript/jquery.timers-1.2.js"></script>

        <script type="text/javascript" src="https://customerportal.utilibill.com.au/ausbbs/cufon/cufon-yui.js"></script>
        <script type="text/javascript" src="https://customerportal.utilibill.com.au/ausbbs/cufon/Myriad_Pro_regular.js"></script>
        <script type="text/javascript" src="https://customerportal.utilibill.com.au/ausbbs/cufon/Myriad_Pro_bolditalic.js"></script>
        <script type="text/javascript" src="https://customerportal.utilibill.com.au/ausbbs/cufon/Festus.js"></script>
        <script type="text/javascript" src="https://customerportal.utilibill.com.au/ausbbs/cufon/Neuropol_400.font.js"></script>
        <script type="text/javascript" src="https://customerportal.utilibill.com.au/ausbbs/cufon/Quicksand_400.font.js"></script>
        <script type="text/javascript" src="https://customerportal.utilibill.com.au/ausbbs/cufon/Quicksandbold_700.font.js"></script>
        <script type="text/javascript" src="https://customerportal.utilibill.com.au/ausbbs/cufon/MgOpen_Modata_400-MgOpen_Modata_700.font.js"></script>
        <script type="text/javascript" src="https://customerportal.utilibill.com.au/ausbbs/cufon/Sansation_300.font.js"></script>
        <script type="text/javascript" src="https://customerportal.utilibill.com.au/ausbbs/cufon/DejaVu_Sans_Condensed_400.font.js"></script>
        <script type="text/javascript" src="https://customerportal.utilibill.com.au/ausbbs/cufon/VAGRounded.font.js"></script>
        <script type="text/javascript" src="https://customerportal.utilibill.com.au/ausbbs/cufon/colympia_700.font.js"></script>
        <script type="text/javascript" src="https://customerportal.utilibill.com.au/ausbbs/cufon/neosanslight_300.font.js"></script>
        <script type="text/javascript" src="https://customerportal.utilibill.com.au/ausbbs/cufon/neosans_500.font.js"></script>
        <script type="text/javascript" src="https://customerportal.utilibill.com.au/ausbbs/cufon/lucidasans_400.font.js"></script>
        <script type="text/javascript" src="https://customerportal.utilibill.com.au/ausbbs/cufon/gothambold_400.font.js"></script>
        
        <script type="text/javascript" src="https://customerportal.utilibill.com.au/ausbbs/cufon/Futura_Bk_BT_400.font.js"></script>
        <script type="text/javascript" src="https://customerportal.utilibill.com.au/ausbbs/cufon/Futura_Md_BT_700.font.js"></script>
        
        <script type="text/javascript" src="https://customerportal.utilibill.com.au/ausbbs/cufon/Calibri.js"></script>
        <script type="text/javascript" src="https://customerportal.utilibill.com.au/ausbbs/cufon/Delicious_700.font.js"></script>
        <script type="text/javascript" src="https://customerportal.utilibill.com.au/ausbbs/cufon/TwCenMTCondensed.js"></script>

        <script type="text/javascript" src="https://customerportal.utilibill.com.au/ausbbs/cufon/myriad_pro_400.font.js"></script> 
        
        <script type="text/javascript" src="https://customerportal.utilibill.com.au/ausbbs/cycle/jquery.cycle.min.js"></script>
        
        <script type="text/javascript">
            function activate()
            {
                document.getElementById("menu1").className+="active";
            }

            $(function() {
                $(".menu").find(".cp1").addClass("current");
                $("#slide1").mouseover(function(){
                    $('#homeMenu').anythingSlider(1);
                });
                $("#slide2").mouseover(function(){
                    $('#homeMenu').anythingSlider(2);
                });
                $("#slide3").mouseover(function(){
                    $('#homeMenu').anythingSlider(3);
                });
                $("#slide4").mouseover(function(){
                    $('#homeMenu').anythingSlider(4);
                });

                $(".homeLinksBg a").hover(
                function(){
                    $(this).parent("td").css({
                        "background":"url(images/homeLinkBg.png)",
                        "background-repeat":"no-repeat",
                        "background-position":"center center"
                    });
                },
                function(){
                    $(this).parent("td").css({
                        "background":"none"
                    });
                });
            });
        </script>
    
        <script src="javascript/global.js" type="text/javascript"></script>
        <script src="javascript/jquery.numeric.js" type="text/javascript"></script>
        <script type="text/javascript">

            Cufon.set('fontFamily', 'Myriad Pro Regular');

            
                
            
                
            
            
                
                
        </script>
            
    </head>
    <body onload="activate(); show_clock();">
        <div class="bodyWrapper">
            <div class="bodyWrapper2">
            <div class="header">
                <div class="header3">
                    <div class="header2 ui-corner-bottom">
                        <div style="height:100%;">
                            
                            <a id="companySite" href="https://braintechnosys.biz/isp/cms/staticpage/homepage" class="companyLogo"></a>
                             
                            
                            <table cellspacing="0" cellpadding="0" border="0">
                                <tbody>
                                    <tr class="headerPanel">
                                        <td width="15"><img alt="" height="26" width="15" src="images/southernPhone/left-top.jpg"></td>
                                        <td width="373" style="background:url('images/southernPhone/bg-top.jpg');"  align="right" class="top">Community Based &nbsp;&nbsp;:&nbsp;&nbsp;Community Owned&nbsp;&nbsp;:&nbsp;&nbsp;100% Australian</td>
                                        <td width="15"><img alt="" height="26" width="15" src="images/southernPhone/right-top.jpg"></td>
                                    </tr>
                                   
                                    
                                    <tr class="headerInfo">
                                        <td colspan="3" align="right">
                                            <!--[if lt IE 9 ]>
                                                <script language="javascript" src="javascript/liveclock_IE.js">
                                                </script><![endif]-->
                                                 <!--[if IE 9 ]>
                                                <script language="javascript" src="javascript/liveclock.js">
                                                </script><![endif]--> 
                                            <!--[if !IE]><![IGNORE[--><![IGNORE[]]>
                                            <script type="text/javascript" language="javascript" src="javascript/liveclock.js">
                                            </script><!--<![endif]-->

                                        </td>
                                    </tr>
                                    <tr class="headerInfo">
                                        <td colspan="3" align="right">
                                            <b style="font-size: 12px;" class="welcome-content">
                                                
                                                Welcome:&nbsp;
                                                
                                                Mr&nbsp;manish&nbsp;mishra
                                                
                                                
                                            </b>
                                        </td>
                                    </tr>
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    

                                    
                                </tbody>
                            </table>
                            
                            
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="menuContainer">
                <div class="surround">
                    <div class="surround2">
                        <div class="surround3">
                            <div class="menubar3">
                                <div class="menubar2">
                                    <span class="line"></span>
                                    <div class="menu">
                                        <ul>
                                            <li class="cp1">
                                                
                                                    <a href="https://customerportal.utilibill.com.au/ausbbs/Welcome.do" id="menu1" onmouseover="(window.status=''); return true"><span>
                                                        Home
                                                    </span></a>
                                                
                                            </li>
                                            <li class="cp2">
                                                
                                                <a href="https://customerportal.utilibill.com.au/ausbbs/UnbilledCalls.do" id="menu2"><span>
                                                        Unbilled
                                                    </span></a>
                                                
                                            </li>
                                            
                                           
                                            <li class="cp3">
                                                
                                                <a href="/ausbbs/DataServices.do" id="menu3"><span>
                                                        Services
                                                    </span></a>
                                                
                                            </li>
                                            
                                            <li class="cp4">
                                                
                                                <a href="/ausbbs/Statements.do" id="menu4"><span>
                                                        Statements
                                                    </span></a>
                                                
                                            </li>
                                            <li class="cp5">
                                                
                                                <a href="/ausbbs/Payments.do" id="menu5"><span>
                                                        Payments
                                                    </span></a>
                                                
                                            </li>
                                            <li class="cp6">
                                                
                                                
                                                    
                                                    <a href="/ausbbs/MakePayment.do" id="menu6"><span>
                                                            Make A Payment
                                                        </span></a>
                                                    

                                            </li>
                                            <li class="cp7">
                                                
                                                    <a href="/ausbbs/CreditRemaining.do" id="menu7"><span>
                                                            Credit Remaining
                                                        </span></a>
                                                
                                            </li>
                                            <li class="cp8">
                                                
                                                <a href="/ausbbs/DisplayCustomerProfile.do" id="menu8"><span>
                                                        Personal Details
                                                    </span></a>
                                                
                                            </li>
                                            <li class="cp9">
                                                <a href="/ausbbs/Logout.do?id=48"><span>
                                                        Logout
                                                    </span></a>
                                            </li>
                                        </ul>
                                       
                                        <div class="tlheadercurve"></div>
                                        <div class="trheadercurve"></div>
                                    </div> 
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div id="mainContainer" class="mainContainer">
                <div class="surround">
                    <div class="surround2">
                        <div class="surround3">
                            <div class="main" >
                                <div class="mainTitle shadow">
                                    <div class="mainTitleContainer">
                                        <h1 style="float:left">Welcome To Our Customer Portal</h1>
                                        
                                    </div>
                                    <div class="blheadercurve"></div>
                                    <div class="brheadercurve"></div>
                                </div>
                                <img class="contentBorder" src="images/southernPhone/main_border.jpg" alt=""/>
                                <div class="mainContent" align="center">
                                    
        
        
        <div class="tableHomeContent"> 
        <br/>
        <h4 style="text-align:left;" class="homeH4">Here you can</h4>
        <table class="homeTable" cellspacing="0" cellpadding="0">
            <tr class="homeLinksSlide">
                <td colspan="4" align="center">
                    <div id="homeMenu">
                        <div class="balance">
                            <a href="/ausbbs/Statements.do"><h1 class="homeLinks">View your Statement</h1></a>
                        </div>
                        <div class="call">
                            
                            <a href="/ausbbs/UnbilledCalls.do"><h1 class="homeLinks">View your Call Details</h1></a>
                            
                        </div>
                        
                        <div class="payment">
                            <a href="/ausbbs/MakePayment.do"><h1 class="homeLinks">Make Payments</h1></a>
                        </div>
                        
                        <div class="userProfile">
                            <a href="/ausbbs/DisplayCustomerProfile.do"><h1 class="homeLinks">View your Personal Details</h1></a>
                        </div>
                    </div>
                </td>
            </tr>
            <tr class="homeLinksBg">
                <td colspan="1" align="center">
                    <a href="/ausbbs/Statements.do" id="slide1" class="homeLink"><img alt="" src="images/bill2.png"/></a>
                </td>
                <td colspan="1" align="center">
                    
                    <a href="/ausbbs/UnbilledCalls.do" class="homeLink"><img alt="" src="images/call2.png"/></a>
                    
                </td>
                
                <td colspan="1" align="center"> 
                    <a href="/ausbbs/MakePayment.do" class="homeLink"><img alt="" src="images/payment2.png"/></a>
                </td>
                
                <td colspan="1" align="center" class="last-td">
                    <a href="/ausbbs/DisplayCustomerProfile.do" class="homeLink"><img alt="" src="images/user2.png"/></a>
                </td>
            </tr>
            <!--<tr>
                <td colspan="4" id="menuDescription" align="center">
                    <h1 id="desc1" class="hiddenTable">View your Statement</h1>
                    <h1 id="desc2" class="hiddenTable">
            
            View your Call Details
            
        </h1>
        <h1 id="desc3" class="hiddenTable">Make Payments</h1>
            <h1 id="desc4" class="hiddenTable">View your Personal Details</h1>
    </td>
</tr>-->
        </table>
        </div>
        
    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                
            </div>
            
            
            <div class="bodycurvetl"></div>
            <div class="bodycurvetr"></div>
            <div class="bodycurvebl"></div>
            <div class="bodycurvebr"></div>
        </div>
        </div>
    </body>
</html>

