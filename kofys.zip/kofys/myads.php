<?php   
	
	include "includes/common.php";
	include_once $config['SiteClassPath']."class.Register.php";
	include $config['SiteClassPath']."class.split_page_results.php";
	include_once $config['SiteClassPath']."class.myads.php";
	
	
	$Objmyads=new myads();
	
	$ObjReg=new Register();
	
	$ObjReg->LoginCheck();  
	
								 
	$pagelimit=$_REQUEST['pagelimit'];
	echo $page=$_REQUEST['page'];
	if($_REQUEST['uid']!='')
	{
	
	//$DelQuery = "update tbl_member set status =1 Where id IN ( ".$BanIds." )" ;
	$updat = "update tbl_category set status = 0 where category_id = '".$_REQUEST['uid']."'";
	//$DelQry="Delete from tbl_category where category_id='".$_REQUEST['uid']."'";
	$Objmyads->ExecuteQuery($updat,"update");
	}
	
	if($_REQUEST['clog']!='')
	{
		
	//$DelQry="Delete from tbl_track where cat_id='".$_REQUEST['clog']."'";
	$DelQry="Delete from tbl_category_count where category_id='".$_REQUEST['clog']."'";
	$Objmyads->ExecuteQuery($DelQry,"delete");
	}
	
	
	
	if($_SESSION['userid']!=='')
	{
	$Objmyads->select_myads();	
	}

	$Objmyads->counter();	
	$objSmarty->assign("page",$page); 
	$objSmarty->assign("pagelimit",$pagelimit); 
	$objSmarty->assign("ObjReg",$ObjReg); 
	$objSmarty->assign("IncludeTpl", "myads.tpl");
	$objSmarty->display("pagetemplate.tpl"); 
	
?>