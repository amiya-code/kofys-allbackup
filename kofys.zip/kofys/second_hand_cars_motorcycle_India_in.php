<?php   
	
	include "includes/common.php";
	include_once $config['SiteClassPath']."class.sitemap.php";
	include $config['SiteClassPath']."class.split_page_results.php";
	$objsitemap = new sitemap;
	
    $objsitemap->second_hand_cars_motorcycle_India_in();
	
	$objSmarty->assign("ObjReg",$ObjReg); 
	$objSmarty->assign("IncludeTpl", "second_hand_cars_motorcycle_India_in.tpl");	 
	$objSmarty->display("pagetemplate.tpl"); 
	
?>