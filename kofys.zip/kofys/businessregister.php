<?php 
	include "includes/common.php";
	include_once $config['SiteClassPath']."class.Register.php";
	
	$ObjReg=new Register();
	
	if($_SESSION['userid']!='')
	{
	 header("location:profile.php");
	 }
	
	
	if($_POST['login']!='')
	{
		$ObjReg->Check_MemberLog($_REQUEST);
	}
	
	if($_POST['regist']!='')
	{
	   $ObjReg->Newmember_Register();  
	}
	
	
	
	$ObjReg->Get_Country();
	
$objSmarty->assign("ObjReg",$ObjReg);
$objSmarty->assign("IncludeTpl", "business.tpl");
$objSmarty->display("pagetemplate.tpl");
?>