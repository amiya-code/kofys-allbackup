<?php   
	
	include "includes/common.php";
	include_once $config['SiteClassPath']."class.sitemap.php";
	include $config['SiteClassPath']."class.split_page_results.php";
	$objsitemap = new sitemap;
	
	$objsitemap->Motorcycles_for_Sale_in_Orlando();
	
	$objSmarty->assign("ObjReg",$ObjReg); 
	$objSmarty->assign("IncludeTpl", "Motorcycles_for_Sale_in_Orlando.tpl");	 
	$objSmarty->display("pagetemplate.tpl"); 
	
?>