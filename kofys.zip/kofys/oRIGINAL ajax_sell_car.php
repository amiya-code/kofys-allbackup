<?php 
include "includes/common.php";
$sql= new MysqlFns();

extract($_REQUEST);
$result1="select * from tbl_category where sub_parent_id='$category_id' group by model asc ";
$exe=$sql->ExecuteQuery($result1,"select");
$cnt = count($exe);

if($cnt != '')
{
echo '<select id="model" name="model" class="dd" onchange="vali1();">
<option value="">Select Model</option>';
foreach($exe as $val){
echo "<option value=\"$val[model]\" >$val[model]</option>";
}
echo "</select>";
}else{

echo '<input type="text" name="model" id="model" />';
}

?>