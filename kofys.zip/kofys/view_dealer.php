<?php   
	
	include "includes/common.php";
	include_once $config['SiteClassPath']."class.Register.php";
	include $config['SiteClassPath']."class.split_page_results.php";
	include_once $config['SiteClassPath']."class.index.php";
	include_once $config['SiteClassPath']."class.dealer.php";
	
	
	$ObjIndex=new Index();
	
	$ObjReg=new Register();
	
	$objdealer=new dealer();
	
	$ObjReg->Get_Recent_mem();
	
	$ObjReg->Get_Country(); 
	
	
	
	if($_POST['login']!='') 
	{
	$page="home";
	$ObjReg->Check_MemberLog($_REQUEST,$page);
	} 
	
	
	
	if($_REQUEST['user_id']!=='')
	{
	$objdealer->view_dealer_details();
	
	$objdealer->view_dealer_products();
	
	}
	
	
	
	
	$objSmarty->assign("objdealer",$objdealer); 
	$objSmarty->assign("ObjReg",$ObjReg); 
	$objSmarty->assign("IncludeTpl", "view_dealer.tpl");
	$objSmarty->display("pagetemplate.tpl"); 
	
?>