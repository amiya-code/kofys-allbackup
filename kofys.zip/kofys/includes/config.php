<?php 
//error_reporting(1);
/*   Global Variables   */



##############################



    
 


	 $config['SiteGlobalPath']		= "https://braintech/app/kofys"; 

	if($mode == "dev"){
		define('BASE_PATH',$_SERVER['DOCUMENT_ROOT'].'/dev');
	}else{
		define('BASE_PATH',$_SERVER['DOCUMENT_ROOT']);
	}
	//pr(BASE_PATH);

	$config['SiteLocalPath']		= BASE_PATH."/";



	$config['SiteClassPath']		= BASE_PATH."/includes/classes/";



	$config['SiteTemplatesPath']	= $config['SiteLocalPath']."templates/";



	$config['SiteLink']				= "<a href='".$config['SiteGlobalPath']."'>Providers Area</a>";



	$config['SiteTemplatesHeader']	= $config['SiteTemplatesPath']."header.tpl";



	$config['SiteTemplatesInnerHeader']	= $config['SiteTemplatesPath']."inner_header.tpl";



	$config['AlbumPhotoPath']= $config['SiteLocalPath']."UploadImage/";


	$config['SiteProductPath']	= $config['SiteLocalPath']."Products/";



	$config['BlogPath']	= $config['SiteLocalPath']."BlogImage/";



	$config['SiteVideoPath']	= $config['SiteLocalPath']."videofiles/";







	$config['SiteTemplatesFooter']	= $config['SiteTemplatesPath']."footer.tpl";



	



	 



/*   Global Site Variables   */



##############################



	$config['SiteTitle']	  	= "https://braintech/app/kofys/";



	$config['SiteMail']			= "info@kofys.com";



	$config['AdminMail']		= "admin@kofys.com";
	
	$config['phone']		= "12345678";



	



		$config['success']		= BASE_PATH."/kofys2/success_pay.php";



		$config['cancel']		= BASE_PATH."/kofys2/cancel_pay.php";



/*local	Database Settings	*/



##############################







	//$config['DBHostName']	= "css_dbase.db.3371006.hostedresource.com";
	$config['DBHostName']	= "localhost";


	$config['DBUserName']	= "qbzvfeub_kofys";

    //$config['DBUserName']	= "root";

	$config['DBPassword']	= "braintech@123";

	//$config['DBPassword']	= "bt123";

	$config['DBName']		= "qbzvfeub_kofys";


	 



	







/*	Page Navigation Settings	*/



##############################



	$config['Limit'] = 20;	



	



	



/* Setting some necessary values Here */



	#######################################



	
	
	$config['today']=date('Y-m-d');



/* Setting some necessary values Here */



	#######################################


//code to set maximum executuin time!

// set_time_limit(120);
 ini_set('max_execution_time', 0);
 ini_set('max_upload_filesize', 104857600);



?>



