<?php 



/*   Global Variables   */



##############################



    
 

			ini_set('memory_limit', '-1');
	 $config['SiteGlobalPath']		= "hhttps://173.201.141.145/"; 

 



	$config['SiteLocalPath']		= $_SERVER['DOCUMENT_ROOT']."/";



	$config['SiteClassPath']		= $_SERVER['DOCUMENT_ROOT']."/includes/classes/";



	$config['SiteTemplatesPath']	= $config['SiteLocalPath']."templates/";



	$config['SiteLink']				= "<a href='".$config['SiteGlobalPath']."'>Providers Area</a>";



	$config['SiteTemplatesHeader']	= $config['SiteTemplatesPath']."header.tpl";



	$config['SiteTemplatesInnerHeader']	= $config['SiteTemplatesPath']."inner_header.tpl";



	$config['AlbumPhotoPath']= $config['SiteLocalPath']."UploadImage/";


	$config['SiteProductPath']	= $config['SiteLocalPath']."Products/";



	$config['BlogPath']	= $config['SiteLocalPath']."BlogImage/";



	$config['SiteVideoPath']	= $config['SiteLocalPath']."videofiles/";







	$config['SiteTemplatesFooter']	= $config['SiteTemplatesPath']."footer.tpl";



	



	 



/*   Global Site Variables   */



##############################



	$config['SiteTitle']	  	= "kofys.com";



	$config['SiteMail']			= "info@kofys.com";



	$config['AdminMail']		= "admin@kofys.com";
	
	$config['phone']		= "Kofys@#2020";



	



		$config['success']		= $_SERVER['DOCUMENT_ROOT']."/kofys2/success_pay.php";



		$config['cancel']		= $_SERVER['DOCUMENT_ROOT']."/kofys2/cancel_pay.php";



/*local	Database Settings	*/



##############################







	//$config['DBHostName']	= "css_dbase.db.3371006.hostedresource.com";
	$config['DBHostName']	= "184.168.154.105";


	//$config['DBUserName']	= "css_dbase";

    $config['DBUserName']	= "braintech";

	//$config['DBPassword']	= "Nicole18_css";

	$config['DBPassword']	= "NewsiteDBkf1";

	$config['DBName']		= "braintech";


	 



	







/*	Page Navigation Settings	*/



##############################



	$config['Limit'] = 20;	



	



	



/* Setting some necessary values Here */



	#######################################



	
	
	$config['today']=date('Y-m-d');



/* Setting some necessary values Here */



	#######################################


//code to set maximum executuin time!

// set_time_limit(0);
 ini_set('max_execution_time', 0);
 ini_set('max_upload_filesize', '100M');
 ini_set('memory_limit', '100M');
 ini_set('post_max_size', '100M');
 ini_set('file_uploads', 'On');







?>



