<?php 
ob_start();
session_start();
//if ($_SERVER['SERVER_PORT']==443)
//{
//$url = "https://". $_SERVER['SERVER_NAME'] .$_SERVER['REQUEST_URI']; 
//header("Location:$url");
//}
	$mode = "live";
	error_reporting(E_ALL);
	ini_set("display_errors", 1); 
	//ini_set('memory', '-1');
	@set_time_limit(0);
	ini_set('memory_limit', '200M');
    ini_set('post_max_size', '200M');
    ini_set('upload_max_filesize', '200M'); 
	ini_set('error_reporting', E_ALL ^ E_NOTICE);
	//echo "<pre>";
	//print_r(getcwd());die;
	//
	function pr($data){
		echo "<pre>";
		print_r($data);
		echo "</pre>";
	}
	function getLatLong($city=null,$state=null,$country=null,$zip=null){ 
		if(true){
			//pr('test');die;
			//if(isset($city) && isset($zip)){
			if(isset($zip)){
				//if(!empty($city) && !empty($zip)){
				if(!empty($zip)){
					//Formatted address
					//pr("kjhwker");
					$address = implode(" ",array_filter(array($city,$state,$country,$zip)));
					//pr("ABCD!");
					$formattedAddr = str_replace(' ','+',$address);
					//Send request and receive json data by address
					$url="https://maps.googleapis.com/maps/api/geocode/json?address=$formattedAddr&key=AIzaSyAEAUCY_2f2VOLbKIeYzbmvBWT_tp7D6bQ";
					
					//pr($url);die;
					//phpinfo();
					$curl = curl_init();
					//pr($url);die
					curl_setopt($curl, CURLOPT_URL, $url);
					curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
					curl_setopt($curl, CURLOPT_HEADER, false);
					$geocodeFromAddr = curl_exec($curl);
					curl_close($curl);
					$output = json_decode($geocodeFromAddr);
					//pr($output);die; 
					if($output->status =='OK'){
						//Get latitude and longitute from json data
						$arr['lat']  = $output->results[0]->geometry->location->lat; 
						$arr['long'] = $output->results[0]->geometry->location->lng;
					}
					//Return latitude and longitude of the given address
					if(!empty($arr)){
						return $arr;
					}
				}
			}
		}
	}
	
	function getFileDelimiter($file, $checkLines = 2){
        $file = new SplFileObject($file);
        $delimiters = array(
          ",",
          "\t",
          ";",
          "|",
          ":"
        );
        $results = array();
        $i = 0;
         while($file->valid() && $i <= $checkLines){
            $line = $file->fgets();
            foreach ($delimiters as $delimiter){
                $regExp = '/['.$delimiter.']/';
                $fields = preg_split($regExp, $line);
                if(count($fields) > 1){
                    if(!empty($results[$delimiter])){
                        $results[$delimiter]++;
                    } else {
                        $results[$delimiter] = 1;
                    }   
                }
            }
           $i++;
        }
        $results = array_keys($results, max($results));
        return $results[0];
    }
	
	if(!defined("_MAINSITEPATH_")){	
		//pr($_SERVER['DOCUMENT_ROOT']);
		if($mode == "dev"){
			define("_MAINSITEPATH_",$_SERVER['DOCUMENT_ROOT']."/dev/includes/");
			define("WWW_ROOT",$_SERVER['DOCUMENT_ROOT']."/dev");
			define("WWW_BASE",$_SERVER['HTTP_HOST']."/dev");
		}else{
			define("_MAINSITEPATH_",$_SERVER['DOCUMENT_ROOT']."/includes/");
			define("WWW_ROOT",$_SERVER['DOCUMENT_ROOT']);
			define("WWW_BASE",$_SERVER['HTTP_HOST']);
		}
		//pr(WWW_BASE);
		//pr($mode);die;
		//define("_MAINSITEPATH_",getcwd()."/includes/");
		//define("_MAINSITEPATH_","/home/content/93/7587393/html/kofystest/includes/");
		//pr(_MAINSITEPATH_);
	}
	if(!defined("EMAIL_LINEFEED"))
	define("EMAIL_LINEFEED",'CRLF');
	if(!defined("EMAIL_TRANSPORT"))
		define("EMAIL_TRANSPORT",'smtp');
	if(!defined("CHARSET"))
		define("CHARSET",'iso-8859-1');
	define('PREVNEXT_BUTTON_PREV', '<b>&lt;&lt;</b>');
	define('PREVNEXT_BUTTON_NEXT', '<b>&gt;&gt;</b>');
	define('TEXT_DISPLAY_NUMBER_OF_INVITES', 'Displaying <b>%d</b> to <b>%d</b> (of <b>%d</b> Invites)');
	define('TEXT_DISPLAY_NUMBER_OF_INBOX', 'Displaying <b>%d</b> to <b>%d</b> (of <b>%d</b> Mails)');
	define('TEXT_DISPLAY_NUMBER_OF_FIND', 'Search Result  <b>%d</b> to <b>%d</b> (of <b>%d</b> Matches)');
	define('TEXT_DISPLAY_NUMBER_OF_UPEVENTS', 'UpComing  <b>%d</b> to <b>%d</b> (of <b>%d</b> Events)');
	define('TEXT_DISPLAY_NUMBER_OF_PASTEVENTS', 'Past  <b>%d</b> to <b>%d</b> (of <b>%d</b> Events)');
	define('TEXT_DISPLAY_NUMBER_OF_COMMENTS', 'Displaying  <b>%d</b> to <b>%d</b> Comment(s)');
	define('TEXT_DISPLAY_NUMBER_OF_FAVORITES', 'Listing  <b>%d</b> to <b>%d</b> Favorites(s)');	
	define('TEXT_DISPLAY_NUMBER_OF_ADDRESS', 'Listing  <b>%d</b> to <b>%d</b> Address(s)');	
	define('TEXT_DISPLAY_NUMBER_OF_RESULT', '<b>%d</b> to <b>%d</b> (of <b>%d</b>)');
	define('TEXT_RESULT_PAGE', 'Page %s of %d');
	define('TEXT_RESULT_PAGE1', 'Result Pages:');
	define('PREVNEXT_TITLE_FIRST_PAGE', 'First Page');
	define('PREVNEXT_TITLE_PREVIOUS_PAGE', 'Previous Page');
	define('PREVNEXT_TITLE_NEXT_PAGE', 'Next Page');
	define('PREVNEXT_TITLE_LAST_PAGE', 'Last Page');
	define('PREVNEXT_TITLE_PAGE_NO', 'Page %d');
	define('PREVNEXT_TITLE_PREV_SET_OF_NO_PAGE', 'Previous Set of %d Pages');
	define('PREVNEXT_TITLE_NEXT_SET_OF_NO_PAGE', 'Next Set of %d Pages');
	define('PREVNEXT_BUTTON_FIRST', '&lt;&lt;FIRST');
	define('PREVNEXT_BUTTON_PREV1', '[&lt;&lt;&nbsp;Prev]');
	define('PREVNEXT_BUTTON_NEXT1', '[Next&nbsp;&gt;&gt;]');
	define('PREVNEXT_BUTTON_LAST', 'LAST&gt;&gt;');
	/*Default Country For Browse */
	define('B_COUNTRY', 219);
	define('B_STATES', 3564);
	include_once _MAINSITEPATH_."config.php";
	include_once $config['SiteClassPath']."class.SqlFunctions.php";
	include_once $config['SiteClassPath']."class.General.php";
	include_once $config['SiteClassPath']."class.Mime.php";
	include_once $config['SiteLocalPath']."includes/smarty/Smarty.class.php";
	define ("CONFIGS_PATH",$config['SiteGlobalPath']. "/configs");
	global $config;
	$objSmarty	= new Smarty();
		global $objSmarty;
		$objMysqlFns	= new MysqlFns();
		$Query			= "select * from tbl_confiq where Ident = 1";
		$Result			= $objMysqlFns->ExecuteQuery($Query, "select");
		$adminfname   = $Result[0]['fname'];
		$adminlname   = $Result[0]['lname'];
		$adminemail   = $Result[0]['email'];
		$admincity   = $Result[0]['city'];
		$adminstate   = $Result[0]['state'];
		$adminphone   = $Result[0]['phone'];
		$adminzipcode   = $Result[0]['zipcode'];
		  //@session_register("adminemail");
		 // pr($Result);die;
		  //@session_register("adminfname");
	      @$_SESSION['adminemail']=$adminemail;
	      @$_SESSION['adminfname']=$adminfname;
		$objSmarty->assign("adminfname", $adminfname);
		$objSmarty->assign("adminlname", $adminlname);
		$objSmarty->assign("adminemail", $adminemail);
		$objSmarty->assign("admincity", $admincity);
		$objSmarty->assign("adminstate", $adminstate);
		$objSmarty->assign("adminphone", $adminphone);
		$objSmarty->assign("adminzipcode", $adminzipcode);
if (!empty($_REQUEST['lang'])) {
    $_SESSION['lang'] = $_REQUEST['lang'];
}else{
	$_SESSION['lang'] = "english.conf";
}
/*if ($_POST['action'] == "") {
    $post_vars = ProcessAction ($_POST);
}
 foreach ($post_vars as $key=>$val) {
    $posted_data .= "$key=$val<br>";
}
$objSmarty->assign ("posted_data", $posted_data);*/
function ProcessAction ($post_vars) {
    // This code makes it so you can translate the buttons and convert 
    // the english text which is cleverly passed in the name field seperated
    // by a | (pipe) character.  ex: "action|Add"
    foreach ($post_vars as $key => $val) {
        if (preg_match ("/^action\|(.*)/", $key,$matches)) {
            unset($post_vars[$key]);
            $post_vars['action'] .= $matches[1];
        }
    }
    return $post_vars;
}
	function NavigationLink($NavigationLinks)
	{
		global $objSmarty, $config;
		$Navigation	= " <a href='".$config['SiteGlobalPath']."'  class='Navigation'> Home </a>";
		if(!empty($NavigationLinks) && is_array($NavigationLinks))
			foreach($NavigationLinks as $key=>$value)
			{
				$Navigation .= " >> ". " <a href='".$NavigationLinks[$key]['Link']."'  class='Navigation'> ".$NavigationLinks[$key]['Title']." </a>";
			}
		$objSmarty->assign("NavigationLinks", $Navigation);
	}
	function printArray($Array)
	{
		print "<Pre>";
		print_r($Array);
		print "</Pre>";
	}
	function Redirect($Url)
	{
		header("Location:".$Url);
		exit;
	}
	function PrePopulate($objArray, $ArrayName='')
	{
		global $objSmarty;
		if(!empty($objArray) && is_array($objArray))
		{
			if(!empty($ArrayName))
			{	
				$Array = array();
				foreach($objArray as $key=>$value)
					$Array[$key] = $value;
				$$ArrayName	= $Array;
				$objSmarty->assign($ArrayName,$$ArrayName);
			}
			else
			{
				foreach($objArray as $key=>$value)
				{
					$objSmarty->assign($key,$value);
				}
			}
		}
	}
	/*Drop Down Menu Start */
	function draw_pull_down_menu($name, $values, $default = '', $parameters = '', $required = false) {
    $field = '<select name="' . output_string($name) . '"';
    if (not_null($parameters)) $field .= ' ' . $parameters;
    $field .= '>';
    if (empty($default) && isset($GLOBALS[$name])) $default = stripslashes($GLOBALS[$name]);
    for ($i=0, $n=sizeof($values); $i<$n; $i++) {
      $field .= '<option value="' . output_string($values[$i]['id']) . '"';
      if ($default == $values[$i]['id']) {
        $field .= ' SELECTED';
      }
      $field .= '>' . output_string($values[$i]['text'], array('"' => '&quot;', '\'' => '&#039;', '<' => '&lt;', '>' => '&gt;')) . '</option>';
    }
    $field .= '</select>';
    return $field;
  }
   function not_null($value) {
    if (is_array($value)) {
      if (sizeof($value) > 0) {
        return true;
      } else {
        return false;
      }
    } else {
      if ( (is_string($value) || is_int($value)) && ($value != '') && ($value != 'NULL') && (strlen(trim($value)) > 0)) {
        return true;
      } else {
        return false;
      }
    }
  }
function output_string($string, $translate = false, $protected = false) {
    if ($protected == true) {
      return htmlspecialchars($string);
    } else {
      if ($translate == false) {
        return parse_input_field_data($string, array('"' => '&quot;'));
      } else {
        return parse_input_field_data($string, $translate);
      }
    }
  }
  ////
// Parse the data used in the html tags to ensure the tags will not break
  function parse_input_field_data($data, $parse) {
    return strtr(trim($data), $parse);
  }
function draw_form($name, $action, $parameters = '', $method = 'post', $params = '') 
{
	$form = '<form name="' . output_string($name) . '" action="';
		if (not_null($parameters)) 
		{
		$form .= href_link($action, $parameters);
		} 
		else 
		{
		$form .= href_link($action);
		}
		$form .= '" method="' . output_string($method) . '"';
		if (not_null($params)) 
		{
		$form .= ' ' . $params;
		}
		$form .= '>';
	return $form;
}
  function href_link($page = '', $parameters = '', $connection = 'NONSSL') 
  {
    /*if ($page == '') {
      die('</td></tr></table></td></tr></table><br><br><font color="#ff0000"><b>Error!</b></font><br><br><b>Unable to determine the page link!<br><br>Function used:<br><br>href_link(\'' . $page . '\', \'' . $parameters . '\', \'' . $connection . '\')</b>');
    }
    if ($connection == 'NONSSL') 
	{
     // $link = HTTP_SERVER . DIR_WS_ADMIN;
	 $link = $config['SiteGlobalPath'];
    }
	else 
	{
      die('</td></tr></table></td></tr></table><br><br><font color="#ff0000"><b>Error!</b></font><br><br><b>Unable to determine connection method on a link!<br><br>Known methods: NONSSL SSL<br><br>Function used:<br><br>tep_href_link(\'' . $page . '\', \'' . $parameters . '\', \'' . $connection . '\')</b>');
    }*/
    if ($parameters == '') {
      $link = $link . $page . '?' . SID;
    } else {
      $link = $link . $page . '?' . $parameters . '&' . SID;
    }
    while ( (substr($link, -1) == '&') || (substr($link, -1) == '?') ) $link = substr($link, 0, -1);
    return $link;
  }
  function draw_hidden_field($name, $value = '', $parameters = '') {
    $field = '<input type="hidden" name="' . output_string($name) . '"';
    if (not_null($value)) {
      $field .= ' value="' . output_string($value) . '"';
    } elseif (isset($GLOBALS[$name]) && is_string($GLOBALS[$name])) {
      $field .= ' value="' . output_string(stripslashes($GLOBALS[$name])) . '"';
    }
    if (not_null($parameters)) $field .= ' ' . $parameters;
    $field .= '>';
    return $field;
  }
  function convert_linefeeds($from, $to, $string) 
		{
			if ((PHP_VERSION < "4.0.5") && is_array($from)) 
			{
			return ereg_replace('(' . implode('|', $from) . ')', $to, $string);
			} 
			else 
			{
			return str_replace($from, $to, $string);
			}
		}
  /*Drop Down Menu End */
  function get_all_get_params($exclude_array = '') {
    global $HTTP_GET_VARS;
    if (!is_array($exclude_array)) $exclude_array = array();
    $get_url = '';
    if (is_array($HTTP_GET_VARS) && (sizeof($HTTP_GET_VARS) > 0)) {
      reset($HTTP_GET_VARS);
      while (list($key, $value) = each($HTTP_GET_VARS)) {
        if ( (strlen($value) > 0) && ($key != temp_session_name()) && ($key != 'error') && (!in_array($key, $exclude_array)) && ($key != 'x') && ($key != 'y') ) {
          $get_url .= $key . '=' . rawurlencode(stripslashes($value)) . '&';
        }
      }
    }
	//print_r($get_url);
    return $get_url;
  }
   function temp_session_name($name = '') {
    if (!empty($name)) {
      return session_name($name);
    } else {
      return session_name();
    }
  }
  function db_input($string) {
    global $link;
    if (function_exists('mysql_real_escape_string')) {
      return mysql_real_escape_string($string);
    } elseif (function_exists('mysql_escape_string')) {
      return mysql_escape_string($string);
    }
    return addslashes($string);
  }
    function get_uprid($prid, $params) {
    if (is_numeric($prid)) {
      $uprid = $prid;
      if (is_array($params) && (sizeof($params) > 0)) {
        $attributes_check = true;
        $attributes_ids = '';
        reset($params);
        while (list($option, $value) = each($params)) {
          if (is_numeric($option) && is_numeric($value)) {
            $attributes_ids .= '{' . (int)$option . '}' . (int)$value;
          } else {
            $attributes_check = false;
            break;
          }
        }
        if ($attributes_check == true) {
          $uprid .= $attributes_ids;
        }
      }
    } else {
      $uprid = get_prid($prid);
      if (is_numeric($uprid)) {
        if (strpos($prid, '{') !== false) {
          $attributes_check = true;
          $attributes_ids = '';
// strpos()+1 to remove up to and including the first { which would create an empty array element in explode()
          $attributes = explode('{', substr($prid, strpos($prid, '{')+1));
          for ($i=0, $n=sizeof($attributes); $i<$n; $i++) {
            $pair = explode('}', $attributes[$i]);
            if (is_numeric($pair[0]) && is_numeric($pair[1])) {
              $attributes_ids .= '{' . (int)$pair[0] . '}' . (int)$pair[1];
            } else {
              $attributes_check = false;
              break;
            }
          }
          if ($attributes_check == true) {
            $uprid .= $attributes_ids;
          }
        }
      } else {
        return false;
      }
    }
    return $uprid;
  }
////
// Return a product ID from a product ID with attributes
  function get_prid($uprid) {
    $pieces = explode('{', $uprid);
    if (is_numeric($pieces[0])) {
      return $pieces[0];
    } else {
      return false;
    }
  }
   function db_error($query, $errno, $error) { 
    die('<font color="#000000"><b>' . $errno . ' - ' . $error . '<br><br>' . $query . '<br><br><small><font color="#ff0000">[MySql Error]</font></small><br><br></b></font>');
  }
	foreach($config as $key=>$value)
		$objSmarty->assign("gl_".$key,$value);
 	//@include_once "chat/". "cometchat_init.php";
//ob_flush();
?>
