<?php   
	
	include "includes/common.php";
	include_once $config['SiteClassPath']."class.sitemap.php";
	include $config['SiteClassPath']."class.split_page_results.php";
	$objsitemap = new sitemap;
	
    $objsitemap->ventes_de_vehicules_en_fr();
	
	$objSmarty->assign("ObjReg",$ObjReg); 
	$objSmarty->assign("IncludeTpl", "ventes_de_véhicules_en_France_Fr.tpl");	 
	$objSmarty->display("pagetemplate.tpl"); 
	
?>