<?php   
	
	include "includes/common.php";
	
	include $config['SiteClassPath']."class.split_page_results.php";
	include_once $config['SiteClassPath']."class.research.php";
	$objresearch = new research();



	
	if($_REQUEST['rid']!=='')
	{
	$objresearch->view_caresearch();	
	}
	
	
	
	
	
	$objSmarty->assign("IncludeTpl", "view_carresearch.tpl");	 
	$objSmarty->display("pagetemplate.tpl"); 
	
?>