<?php   
	
	include "includes/common.php";
	include_once $config['SiteClassPath']."class.Register.php";
	include $config['SiteClassPath']."class.split_page_results.php";
	include_once $config['SiteClassPath']."class.myads.php";
	
	
	$Objmyads=new myads();
	
	$ObjReg=new Register();
	
	$ObjReg->LoginCheck();  

	if($_REQUEST['uid']!='')
	{
	
	//$DelQuery = "update tbl_member set status =1 Where id IN ( ".$BanIds." )" ;
	//$updat = "update tbl_category set status = 0 where category_id = '".$_REQUEST['uid']."'";
	$DelQry="Delete from tbl_category where category_id='".$_REQUEST['uid']."'";
	$Objmyads->ExecuteQuery($DelQry,"update");
	}
	
	if($_REQUEST['mid']!='')
	{
	
	$date = date("Y-m-d");// current date
    $expiredate = strtotime ( '+4 month' , strtotime ( $date ) ) ;
    $expiredate = date ( 'Y-m-j' , $expiredate );
    $expiredate; 
	
	//$DelQuery = "update tbl_member set status =1 Where id IN ( ".$BanIds." )" ;
	$updat = "update tbl_category set status = 1,date = now(),expire_date = '".$expiredate."' where category_id = '".$_REQUEST['mid']."'";
	//$DelQry="Delete from tbl_category where category_id='".$_REQUEST['uid']."'";
	$Objmyads->ExecuteQuery($updat,"update");
	}
	
	
	
	
	if($_SESSION['userid']!=='')
	{
	$Objmyads->select_relist();	
	}
	
	


	 
	$objSmarty->assign("ObjReg",$ObjReg); 
	$objSmarty->assign("IncludeTpl", "relist.tpl");
	$objSmarty->display("pagetemplate.tpl"); 
	
?>