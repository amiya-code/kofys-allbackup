<?php   
	
	include "includes/common.php";
	include_once $config['SiteClassPath']."class.sitemap.php";
	include $config['SiteClassPath']."class.split_page_results.php";
	$objsitemap = new sitemap;
	
    $objsitemap->cheap_used_car_for_sale_by_owner();
	
	$objSmarty->assign("ObjReg",$ObjReg); 
	$objSmarty->assign("IncludeTpl", "cheap_used_car_for_sale_by_owner.tpl");	 
	$objSmarty->display("pagetemplate.tpl"); 
	
?>