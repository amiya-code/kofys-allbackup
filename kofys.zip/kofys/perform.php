<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
 <HEAD>
  <TITLE>+++++ Paypal Pro +++++</TITLE>
  <META NAME="Generator" CONTENT="Paypal Pro">
  <META NAME="Author" CONTENT="Paypal Pro">
  <META NAME="Keywords" CONTENT="Paypal Pro">
  <META NAME="Description" CONTENT="Paypal Pro">
 </HEAD>
 <BODY>
 <table border='0' width='40%' cellspacing='2' cellpadding='2' align="center">
<?php
require_once("paypal_pro.inc.php");
$firstName =urlencode( $_POST['firstName']);
$lastName =urlencode( $_POST['lastName']);
$creditCardType =urlencode( $_POST['creditCardType']);
$creditCardNumber = urlencode($_POST['creditCardNumber']);
$expDateMonth =urlencode( $_POST['expDateMonth']);
$padDateMonth = str_pad($expDateMonth, 2, '0', STR_PAD_LEFT);
$expDateYear =urlencode( $_POST['expDateYear']);
$cvv2Number = urlencode($_POST['cvv2Number']);
$address1 = urlencode($_POST['address1']);
$address2 = urlencode($_POST['address2']);
$city = urlencode($_POST['city']);
$state =urlencode( $_POST['state']);
$zip = urlencode($_POST['zip']);
$amount = urlencode($_POST['amount']);
$currencyCode="USD";
$paymentType=urlencode($_POST['paymentType']);
$nvpstr='&PAYMENTACTION=Authorization&AMT='.$amount.'&CREDITCARDTYPE='.$creditCardType.'&ACCT='.$creditCardNumber.'&EXPDATE='.         $padDateMonth.$expDateYear.'&CVV2='.$cvv2Number.'&FIRSTNAME='.$firstName.'&LASTNAME='.$lastName.'&STREET='.$address1.'&CITY='.$city.'&STATE='.$state.'&ZIP='.$zip.'&COUNTRYCODE=US&CURRENCYCODE='.$currencyCode;
$paypalPro = new paypal_pro('dodziouz_api1.yahoo.com', 'KL8YP3NUV5WK6QFH', 'Agcfg5RFxkUAc8zYWpyZ47MgcVPwAeUC2Qv-RQq.T5gL8958w0xA1XeP', '', '', TRUE, FALSE );
//$paypalPro = new paypal_pro('ankur_1315994788_biz_api1.braintechnosys.com', '1315994850', 'AuTn1F-RZCuoUNRvb4PkAurP5NfnAsj.bYScvAoncqA6fSK91nA4Fs07', '', '', FALSE, FALSE );
$resArray = $paypalPro->hash_call("doDirectPayment",$nvpstr);
$ack = strtoupper($resArray["ACK"]);

if($ack!="SUCCESS")
{
	echo '<tr>';
		echo '<td colspan="2" style="font-weight:bold;color:red;" align="center">Error! Please check that u will provide all information correctly :(</td>';
	echo '</tr>';
	echo '<tr>';
		echo '<td align="right">Ack:</td>';
		echo '<td>'.$resArray["ACK"].'</td>';
	echo '</tr>';
	echo '<tr>';
		echo '<td align="right">Correlation ID:</td>';
		echo '<td>'.$resArray['CORRELATIONID'].'</td>';
	echo '</tr>';
}
else
{
	echo '<tr>';
		echo '<td colspan="2" style="font-weight:bold;color:Green" align="center">Thank You For Your Payment :)</td>';
	echo '</tr>';
	echo '<tr>';
		echo '<td align="right"> Transaction ID:</td>';
		echo '<td>'.$resArray["TRANSACTIONID"].'</td>';
	echo '</tr>';
	echo '<tr>';
		echo '<td align="right"> Amount:</td>';
		echo '<td>'.$currencyCode.$resArray['AMT'].'</td>';
	echo '</tr>';
}
?>
</table>
 </BODY>
</HTML>