<?php 
	include "includes/common.php";

	include_once $config['SiteClassPath']."class.Register.php";
	include_once $config['SiteClassPath']."class.index.php";
	
	
	$ObjIndex=new Index();

	
   	
	
	$mem_id=$_SESSION["userid"];
	
	$ObjReg=new Register();

	
	$ObjReg->LoginCheck(); 
	
	$ObjReg->Login_UserDetails(); 
	
	
	
	
	
	if($_REQUEST['Save'])
	{
	  
	  $result = $ObjIndex->edit_profile(); 
	  $objSmarty->assign("emailexist",$result);
	 
	 }
	
	$ObjReg->Profile_user($_SESSION); 
	


//$Objsearch->Profile_View($mem_id); 

$objSmarty->assign("ObjReg",$ObjReg);

$objSmarty->assign("IncludeTpl", "edit_profile.tpl");

$objSmarty->display("pagetemplate.tpl");

?>