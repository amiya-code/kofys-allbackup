<?php
include "includes/common.php";
$sql=new  MysqlFns();
global $objSmarty;
 $date=date('Y-m-d');
$seleQry="select category_id,user_id,date,expire_date,status from tbl_category where expire_date='".$date."'";
$result=$sql->ExecuteQuery($seleQry,"select");
//echo count($result);
$USrI = $result[0]['user_id'];
if($result){

  $Updat = "update tbl_category set status = 0,expire_date =2 where expire_date = '".$date."'";
  $res = $sql->ExecuteQuery($Updat,"update");
}

$count = count($result);

for($i=0;$i<$count;$i++){
//$use = $result[$i]['user_id'];
$seleQry1="select * from tbl_member where id='".$result[$i]['user_id']."'";
$result1=$sql->ExecuteQuery($seleQry1,"select");
$fname = $result1['0']['fname'];
$email = $result1['0']['email'];


 $mess='<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "https://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="https://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Kofys</title>
<link href="https://www.kofys.com/stylesheet/style.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
.style1 {font-weight: bold}
.style2 {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: smaller;
}
.style3 {
	font-size: smaller;
	font-family: "Courier New", Courier, monospace;
}
.style5 {
	font-family: Arial, Helvetica, sans-serif;
	font-size: smaller;
}
-->
</style>

</head>

<body>     

<table width="700" border="0" align="center" cellspacing="0" cellpadding="7">
  <tr>
    <td bgcolor="#FFFFFF"><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
       <td height="25" align="center" valign="middle" class="head1text" >Kofys </td></table>
      </tr>
          <tr>
            <td height="35" align="center" bgcolor="#FFFFFF" class="normal_txt7"><table width="97%"  cellspacing="0" cellpadding="0">
              <tr>
                <td height="8"></td>
                <td height="8"></td>
                </tr>
              <tr>
                <td width="15">&nbsp;</td>
                <td height="25" align="left" valign="middle" class="text2" >
                <p>Dear '.$fname.',</p>                
                <span class="text2">Your product has been expired. kindly relist your product again.</span>                
                <p>Click here to <a href="https://www.kofys.com">Kofys.com</a></p>                
                </td></tr><tr>
                <td>&nbsp;</td>
                <td height="25" align="left" valign="middle"> 
                  <br />
<br />

Regards<br />
<br />
Our Team <br />
Founder, Kofys
<br /><br /><br />
              
            </table></td>
          </tr>
        </table></td>
      </tr>
    </table>
</body>
</html>
';

	$subject= "Kofys - Your product has been expired";	
	
	
	$headers  = "MIME-Version: 1.0\r\n";
	$headers .= "Content-type: text/html; charset=iso-8859-1\r\n";
	$headers .= "From:contact@kofys.com <contact@kofys.com>\r\n";

	//$email = 'veeramani@cognostek.com';

	mail($email,$subject,$mess,$headers); 

}




?>