<?php   
	
	include "includes/common.php";
	include_once $config['SiteClassPath']."class.sitemap.php";
	include $config['SiteClassPath']."class.split_page_results.php";
	$objsitemap = new sitemap;
	
    $objsitemap->cars_for_sale_boats_rvs_motorcycles_Iowa_IA();
	
	$objSmarty->assign("ObjReg",$ObjReg); 
	$objSmarty->assign("IncludeTpl", "cars_for_sale_boats_rvs_motorcycles_Iowa_IA.tpl");	 
	$objSmarty->display("pagetemplate.tpl"); 
	
?>