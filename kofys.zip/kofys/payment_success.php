<?php   
	
	include "includes/common.php";
	include_once $config['SiteClassPath']."class.Register.php";
	include $config['SiteClassPath']."class.split_page_results.php";
	include_once $config['SiteClassPath']."class.sell.php";
	$objSell=new sell();
	$cid=$_REQUEST['cid'];
	
	//$objSell->select_rvsmake();
	
	
	//$objSell->select_rvs_review();
	if($_REQUEST['cid']!=='')
	{
	//$objSell->update_status($cid);
	}
	
	if($_REQUEST['type'] == 'success')
	{
		
		$Upd="update tbl_category set status = 1 WHERE category_id='".$_REQUEST['category_id']."'"; 
		$result = $objSell->ExecuteQuery($Upd, "update"); 
		
	}
	
	
	
	$objSmarty->assign("cid",$cid);
	$objSmarty->assign("objSell",$objSell); 
	$objSmarty->assign("IncludeTpl", "payment_success.tpl");	 
	$objSmarty->display("pagetemplate.tpl"); 
	
?>