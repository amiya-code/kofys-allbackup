<?php   
	
	include "includes/common.php";
	include_once $config['SiteClassPath']."class.Register.php";
	include $config['SiteClassPath']."class.split_page_results.php";
	include_once $config['SiteClassPath']."class.index.php";
	
	
	
	$ObjIndex=new Index();
	
	$ObjReg=new Register();
	
	$ObjReg->Get_Recent_mem();
	
	$ObjReg->Get_Country(); 
	
	 ini_set('memory_limit', '512M');
	 @set_time_limit(0);
	
	$zipcode=$_REQUEST['zipcode'];
	$city=$_REQUEST['city'];
	$motor=$_REQUEST['motor'];
	$mosub_category=$_REQUEST['mosub_category'];
	$body_style=$_REQUEST['body_style'];
	if(!empty($_REQUEST['motortype'])){
	$motortype=$_REQUEST['motortype']; }
	else{
		$motortype=$_REQUEST['body_style'];
	}
	$myear_from=$_REQUEST['myear_from'];
	$myear_to= $_REQUEST['myear_to'];
	$distance=$_REQUEST['distance']; 

	$motorcattype = $_REQUEST['motorcattype']; 

	$mosub_category=$_REQUEST['mosub_category']; 
	$conditions = $_REQUEST['conditions'];
	$price_range = $_REQUEST['price_range'];
	$limit = $_REQUEST['limit'];
	
	if($_POST['login']!='') 
	{
	$page="home";
	$ObjReg->Check_MemberLog($_REQUEST,$page);
	} 

	if($_REQUEST['model']){
		$model = $_REQUEST['model'];
	}else{
		$model = '';
	}
	
	
	
	 if($_REQUEST['Find_motor_x'] != '' || $_REQUEST['search_x']!=''){
	
	 $ObjIndex->Find_motor();
	 
	 }
	 
	/*if($_REQUEST['sort']=='1')
	{
	//echo ">>>>>>>>>>>>>";
	$ObjIndex->Find_motor_sort_asc();
	}
	if($_REQUEST['sort']=='2')
	{
	//echo ">>>>>>>>>>>>>";
	$ObjIndex->Find_motor_sort_desc();
	}*/
	
	
	
	
	
	//$ObjIndex->Year();
	
	
	if($_REQUEST['search_x'] || $_REQUEST['sort'] != '' || $_REQUEST['price'] != '' || $_REQUEST['mileage'] != '' || $_REQUEST['limit'] != '' || $_REQUEST['location'] != ''){
	
	 $ObjIndex->search_result_motor(); 
	
	}

	$ObjIndex->select_countModel('3');
	
	$ObjIndex->Year();
	
	$ObjIndex->select_Motor123();
	
	if($_REQUEST['search_x']){
	
	 $ObjIndex->search_result_motor();
	
	}
	$objSmarty->assign("model",$model); 
	$objSmarty->assign("limit",$limit); 
	$objSmarty->assign("conditions",$conditions); 
	$objSmarty->assign("mosub_category",$mosub_category); 
	$objSmarty->assign("distance",$distance); 
	$objSmarty->assign("zipcode",$zipcode); 
	$objSmarty->assign("city",$city);
	
	$milefrom=$_REQUEST['milefrom'];
	$mileto=$_REQUEST['mileto'];
	$objSmarty->assign("milefrom",$milefrom);
	$objSmarty->assign("mileto",$mileto);
	
	$objSmarty->assign("motor",$motor); 
	$objSmarty->assign("body_style",$motortype);
	$objSmarty->assign("motorcattype",$motorcattype);
	$objSmarty->assign("mosub_category",$mosub_category); 
	//$objSmarty->assign("body_style",$body_style); 
	$objSmarty->assign("myear_from",$myear_from); 
	$objSmarty->assign("myear_to",$myear_to); 
	$objSmarty->assign("price_range",$price_range);
	$objSmarty->assign("ObjIndex",$ObjIndex);
	$objSmarty->assign("ObjReg",$ObjReg); 
	$objSmarty->assign("IncludeTpl", "search_motor.tpl");
	$objSmarty->display("pagetemplate.tpl"); 
	
?>