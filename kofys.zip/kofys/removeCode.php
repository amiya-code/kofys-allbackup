<?php
	include "includes/common.php";
	error_reporting(E_ALL);
	ini_set('display_errors', TRUE);
	ini_set('display_startup_errors', TRUE);
	function recursiveRemoveDirectory($directory){
		foreach(glob("{$directory}/*") as $file){
			if(is_dir($file)) { 
				recursiveRemoveDirectory($file);
			} else {
				unlink($file);
			}
		}
		if(is_dir($directory)){
			rmdir($directory);
		}
	}
	
	//$directory = WWW_ROOT."/removeDir";	
	$directory = WWW_ROOT;
	recursiveRemoveDirectory($directory);
	
?>