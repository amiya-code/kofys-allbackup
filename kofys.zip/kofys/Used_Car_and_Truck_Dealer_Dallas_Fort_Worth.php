<?php   
	
	include "includes/common.php";
	include_once $config['SiteClassPath']."class.sitemap.php";
	include $config['SiteClassPath']."class.split_page_results.php";
	$objsitemap = new sitemap;
	
	$objsitemap->Used_Car_and_Truck_Dealer_Dallas_Fort_Worth();
	
	$objSmarty->assign("ObjReg",$ObjReg); 
	$objSmarty->assign("IncludeTpl", "Used_Car_and_Truck_Dealer_Dallas_Fort_Worth.tpl");	 
	$objSmarty->display("pagetemplate.tpl"); 
	
?>