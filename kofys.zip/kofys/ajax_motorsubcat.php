<?php 
	include "includes/common.php";
	$sql= new MysqlFns();
	
	extract($_REQUEST);
	$category_id = $_REQUEST['category_id'];
	
 $result1="select * from tbl_motorcycletype where parent_id='$category_id' order by motor_type asc";
$exe=$sql->ExecuteQuery($result1,"select");
echo '<select id="motortype" name="motortype" class="dd">
<option value="">Select Model</option>';
foreach($exe as $val){
echo "<option value=\"$val[motor_type]\" >$val[motor_type]</option>"; 
}
echo "</select>";
?>