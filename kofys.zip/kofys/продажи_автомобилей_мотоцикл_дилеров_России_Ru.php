<?php   
	
	include "includes/common.php";
	include_once $config['SiteClassPath']."class.sitemap.php";
	include $config['SiteClassPath']."class.split_page_results.php";
	$objsitemap = new sitemap;
	
    $objsitemap->продажи_автомобилей_мотоцикл_дилеров_России_Ru();
	
	$objSmarty->assign("ObjReg",$ObjReg); 
	$objSmarty->assign("IncludeTpl", "продажи_автомобилей_мотоцикл_дилеров_России_Ru.tpl");	 
	$objSmarty->display("pagetemplate.tpl"); 
	
?>