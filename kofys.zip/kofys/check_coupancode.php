<?php
    include "includes/common.php";
	include_once $config['SiteClassPath']."class.Register.php";
    $ObjReg=new Register();
    $coupan_code=$_GET['q'];
    $result1=$ObjReg->chk_valid_coupan($coupan_code);
	//print_r($result1);
    if(!empty($result1)){
		//$result2=$ObjReg->show_subscription_time($coupan_code);	
		//print_r($result1); 
		$sub_time= $result1[0]["subscription_time"];
		echo '1'."*".$sub_time ;
	}
    else{
		echo '0'."*"."" ;
	}
?>