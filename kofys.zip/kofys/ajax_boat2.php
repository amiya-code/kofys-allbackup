<?php 
	include "includes/common.php";
	$sql= new MysqlFns();
    
	extract($_REQUEST);
	
$result1="select * from tbl_category where boat_type ='$category_id' and Make != '' order by Make asc ";
$exe=$sql->ExecuteQuery($result1,"select");
echo '<select id="bosub_category" name="bosub_category" style="width:108px;" onchange="vali1();">
<option value="">Select Model</option>';
foreach($exe as $val){
echo "<option value=\"$val[category_id]\" >$val[Make]</option>";
}
echo "</select>";

?>